namespace GGGC.Admin.AZ.Ordenes.Views
{
    partial class Ordenprint
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox19 = new Telerik.Reporting.TextBox();
            this.textBox20 = new Telerik.Reporting.TextBox();
            this.textBox21 = new Telerik.Reporting.TextBox();
            this.textBox22 = new Telerik.Reporting.TextBox();
            this.textBox23 = new Telerik.Reporting.TextBox();
            this.textBox24 = new Telerik.Reporting.TextBox();
            this.textBox25 = new Telerik.Reporting.TextBox();
            this.textBox26 = new Telerik.Reporting.TextBox();
            this.textBox27 = new Telerik.Reporting.TextBox();
            this.textBox28 = new Telerik.Reporting.TextBox();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.table1 = new Telerik.Reporting.Table();
            this.textBox90 = new Telerik.Reporting.TextBox();
            this.textBox92 = new Telerik.Reporting.TextBox();
            this.textBox94 = new Telerik.Reporting.TextBox();
            this.textBox30 = new Telerik.Reporting.TextBox();
            this.textBox32 = new Telerik.Reporting.TextBox();
            this.textBox34 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox101 = new Telerik.Reporting.TextBox();
            this.textBox68 = new Telerik.Reporting.TextBox();
            this.textBox69 = new Telerik.Reporting.TextBox();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            this.textBox49 = new Telerik.Reporting.TextBox();
            this.textBox50 = new Telerik.Reporting.TextBox();
            this.textBox51 = new Telerik.Reporting.TextBox();
            this.textBox52 = new Telerik.Reporting.TextBox();
            this.Observaciones = new Telerik.Reporting.TextBox();
            this.textBox53 = new Telerik.Reporting.TextBox();
            this.textBox55 = new Telerik.Reporting.TextBox();
            this.shape31 = new Telerik.Reporting.TextBox();
            this.shape30 = new Telerik.Reporting.TextBox();
            this.shape29 = new Telerik.Reporting.TextBox();
            this.shape28 = new Telerik.Reporting.TextBox();
            this.shape27 = new Telerik.Reporting.TextBox();
            this.shape26 = new Telerik.Reporting.TextBox();
            this.shape25 = new Telerik.Reporting.TextBox();
            this.shape24 = new Telerik.Reporting.TextBox();
            this.shape23 = new Telerik.Reporting.TextBox();
            this.shape22 = new Telerik.Reporting.TextBox();
            this.shape21 = new Telerik.Reporting.TextBox();
            this.shape20 = new Telerik.Reporting.TextBox();
            this.objectDataSource1 = new Telerik.Reporting.ObjectDataSource();
            this.shape43 = new Telerik.Reporting.TextBox();
            this.shape42 = new Telerik.Reporting.TextBox();
            this.shape41 = new Telerik.Reporting.TextBox();
            this.shape40 = new Telerik.Reporting.TextBox();
            this.shape39 = new Telerik.Reporting.TextBox();
            this.shape38 = new Telerik.Reporting.TextBox();
            this.shape37 = new Telerik.Reporting.TextBox();
            this.shape36 = new Telerik.Reporting.TextBox();
            this.shape35 = new Telerik.Reporting.TextBox();
            this.shape34 = new Telerik.Reporting.TextBox();
            this.shape33 = new Telerik.Reporting.TextBox();
            this.shape32 = new Telerik.Reporting.TextBox();
            this.shape19 = new Telerik.Reporting.TextBox();
            this.shape18 = new Telerik.Reporting.TextBox();
            this.shape17 = new Telerik.Reporting.TextBox();
            this.shape16 = new Telerik.Reporting.TextBox();
            this.shape15 = new Telerik.Reporting.TextBox();
            this.shape14 = new Telerik.Reporting.TextBox();
            this.shape13 = new Telerik.Reporting.TextBox();
            this.shape12 = new Telerik.Reporting.TextBox();
            this.shape11 = new Telerik.Reporting.TextBox();
            this.shape10 = new Telerik.Reporting.TextBox();
            this.shape9 = new Telerik.Reporting.TextBox();
            this.shape8 = new Telerik.Reporting.TextBox();
            this.shape5 = new Telerik.Reporting.TextBox();
            this.shape6 = new Telerik.Reporting.TextBox();
            this.shape7 = new Telerik.Reporting.TextBox();
            this.shape4 = new Telerik.Reporting.TextBox();
            this.shape2 = new Telerik.Reporting.TextBox();
            this.shape1 = new Telerik.Reporting.TextBox();
            this.shape3 = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(4.72D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox7,
            this.textBox19,
            this.textBox20,
            this.textBox21,
            this.textBox22,
            this.textBox23,
            this.textBox24,
            this.textBox25,
            this.textBox26,
            this.textBox27,
            this.textBox28,
            this.textBox1,
            this.textBox2});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // textBox7
            // 
            this.textBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.302D), Telerik.Reporting.Drawing.Unit.Cm(6.92D));
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.31D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox7.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox7.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox7.Style.Color = System.Drawing.Color.Black;
            this.textBox7.Style.LineColor = System.Drawing.Color.Black;
            this.textBox7.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox7.Value = "";
            // 
            // textBox19
            // 
            this.textBox19.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.088D), Telerik.Reporting.Drawing.Unit.Cm(7.874D));
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.85D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox19.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox19.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox19.Style.Color = System.Drawing.Color.Black;
            this.textBox19.Style.LineColor = System.Drawing.Color.Black;
            this.textBox19.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox19.Value = "";
            // 
            // textBox20
            // 
            this.textBox20.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.802D), Telerik.Reporting.Drawing.Unit.Cm(8.636D));
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.537D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox20.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox20.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox20.Style.Color = System.Drawing.Color.Black;
            this.textBox20.Style.LineColor = System.Drawing.Color.Black;
            this.textBox20.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox20.Value = "";
            // 
            // textBox21
            // 
            this.textBox21.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.079D), Telerik.Reporting.Drawing.Unit.Cm(9.398D));
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.153D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox21.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox21.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox21.Style.Color = System.Drawing.Color.Black;
            this.textBox21.Style.LineColor = System.Drawing.Color.Black;
            this.textBox21.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox21.Value = "";
            // 
            // textBox22
            // 
            this.textBox22.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(6.92D));
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.127D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox22.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox22.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox22.Style.Color = System.Drawing.Color.Black;
            this.textBox22.Style.LineColor = System.Drawing.Color.Black;
            this.textBox22.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox22.Value = "";
            // 
            // textBox23
            // 
            this.textBox23.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.526D), Telerik.Reporting.Drawing.Unit.Cm(7.42D));
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.794D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox23.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox23.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox23.Style.Color = System.Drawing.Color.Black;
            this.textBox23.Style.LineColor = System.Drawing.Color.Black;
            this.textBox23.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox23.Value = "";
            // 
            // textBox24
            // 
            this.textBox24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(7.91D));
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.664D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox24.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox24.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox24.Style.Color = System.Drawing.Color.Black;
            this.textBox24.Style.LineColor = System.Drawing.Color.Black;
            this.textBox24.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox24.Value = "";
            // 
            // textBox25
            // 
            this.textBox25.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(8.4D));
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.664D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox25.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox25.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox25.Style.Color = System.Drawing.Color.Black;
            this.textBox25.Style.LineColor = System.Drawing.Color.Black;
            this.textBox25.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox25.Value = "";
            // 
            // textBox26
            // 
            this.textBox26.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(8.89D));
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.664D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox26.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox26.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox26.Style.Color = System.Drawing.Color.Black;
            this.textBox26.Style.LineColor = System.Drawing.Color.Black;
            this.textBox26.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox26.Value = "";
            // 
            // textBox27
            // 
            this.textBox27.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(9.398D));
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.664D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox27.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox27.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox27.Style.Color = System.Drawing.Color.Black;
            this.textBox27.Style.LineColor = System.Drawing.Color.Black;
            this.textBox27.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox27.Value = "";
            // 
            // textBox28
            // 
            this.textBox28.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(9.906D));
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.664D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox28.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox28.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox28.Style.Color = System.Drawing.Color.Black;
            this.textBox28.Style.LineColor = System.Drawing.Color.Black;
            this.textBox28.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox28.Value = "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.5D), Telerik.Reporting.Drawing.Unit.Cm(2.32D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.508D));
            this.textBox1.Value = "textBox1";
            // 
            // textBox2
            // 
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.954D), Telerik.Reporting.Drawing.Unit.Cm(7.42D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.127D), Telerik.Reporting.Drawing.Unit.Cm(0.398D));
            this.textBox2.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox2.Style.Color = System.Drawing.Color.Black;
            this.textBox2.Style.LineColor = System.Drawing.Color.Black;
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.Value = "";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Inch(2.36D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.table1,
            this.textBox101,
            this.textBox68,
            this.textBox69,
            this.shape5,
            this.shape6,
            this.shape7,
            this.shape4,
            this.shape3,
            this.shape2,
            this.shape1});
            this.detail.Name = "detail";
            this.detail.Style.Visible = true;
            // 
            // table1
            // 
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.362D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.958D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.213D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.884D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.008D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.169D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.914D)));
            this.table1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.61D)));
            this.table1.Body.SetCellContent(0, 0, this.textBox90);
            this.table1.Body.SetCellContent(0, 1, this.textBox92);
            this.table1.Body.SetCellContent(0, 6, this.textBox94);
            this.table1.Body.SetCellContent(0, 2, this.textBox30);
            this.table1.Body.SetCellContent(0, 3, this.textBox32);
            this.table1.Body.SetCellContent(0, 5, this.textBox34);
            this.table1.Body.SetCellContent(0, 4, this.textBox4);
            tableGroup1.Name = "tableGroup1";
            tableGroup2.Name = "tableGroup2";
            tableGroup3.Name = "group1";
            tableGroup4.Name = "group2";
            tableGroup5.Name = "group4";
            tableGroup6.Name = "group3";
            tableGroup7.Name = "group";
            this.table1.ColumnGroups.Add(tableGroup1);
            this.table1.ColumnGroups.Add(tableGroup2);
            this.table1.ColumnGroups.Add(tableGroup3);
            this.table1.ColumnGroups.Add(tableGroup4);
            this.table1.ColumnGroups.Add(tableGroup5);
            this.table1.ColumnGroups.Add(tableGroup6);
            this.table1.ColumnGroups.Add(tableGroup7);
            this.table1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox90,
            this.textBox92,
            this.textBox30,
            this.textBox32,
            this.textBox4,
            this.textBox34,
            this.textBox94});
            this.table1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.572D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.table1.Name = "table1";
            tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup8.Name = "detailTableGroup";
            this.table1.RowGroups.Add(tableGroup8);
            this.table1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.507D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.table1.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.table1.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.table1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.table1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.table1.Style.Color = System.Drawing.Color.Transparent;
            this.table1.Style.LineColor = System.Drawing.Color.Gold;
            this.table1.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(2D);
            // 
            // textBox90
            // 
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.362D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox90.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox90.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox90.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox90.Style.Color = System.Drawing.Color.Black;
            this.textBox90.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox90.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox90.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox90.Value = "= Fields.Field4";
            // 
            // textBox92
            // 
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.958D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox92.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox92.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox92.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox92.Style.Color = System.Drawing.Color.Black;
            this.textBox92.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox92.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox92.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox92.Value = "= Fields.Field6";
            // 
            // textBox94
            // 
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.914D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox94.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox94.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox94.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox94.Style.Color = System.Drawing.Color.Black;
            this.textBox94.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox94.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox94.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox94.StyleName = "";
            this.textBox94.Value = "= Fields.Field8";
            // 
            // textBox30
            // 
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.213D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox30.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox30.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox30.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox30.Style.Color = System.Drawing.Color.Black;
            this.textBox30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox30.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox30.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox30.StyleName = "";
            this.textBox30.Value = "= Fields.Field5";
            // 
            // textBox32
            // 
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.884D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox32.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox32.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox32.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox32.Style.Color = System.Drawing.Color.Black;
            this.textBox32.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox32.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox32.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox32.StyleName = "";
            this.textBox32.Value = "= Fields.Field10";
            // 
            // textBox34
            // 
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.169D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox34.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox34.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox34.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox34.Style.Color = System.Drawing.Color.Black;
            this.textBox34.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox34.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox34.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox34.StyleName = "";
            this.textBox34.Value = "= Fields.Field7";
            // 
            // textBox4
            // 
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.008D), Telerik.Reporting.Drawing.Unit.Cm(0.61D));
            this.textBox4.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox4.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.textBox4.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.Color = System.Drawing.Color.Black;
            this.textBox4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox4.StyleName = "";
            this.textBox4.Value = "= Fields.Field9";
            // 
            // textBox101
            // 
            this.textBox101.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.7D), Telerik.Reporting.Drawing.Unit.Inch(1.85D));
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.803D), Telerik.Reporting.Drawing.Unit.Inch(0.177D));
            this.textBox101.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox101.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.Color = System.Drawing.Color.Black;
            this.textBox101.Style.Font.Bold = true;
            this.textBox101.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox101.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox101.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox101.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox101.Value = "";
            // 
            // textBox68
            // 
            this.textBox68.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.7D), Telerik.Reporting.Drawing.Unit.Inch(2D));
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.803D), Telerik.Reporting.Drawing.Unit.Inch(0.177D));
            this.textBox68.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox68.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.Color = System.Drawing.Color.Black;
            this.textBox68.Style.Font.Bold = true;
            this.textBox68.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox68.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox68.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox68.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox68.Value = "";
            // 
            // textBox69
            // 
            this.textBox69.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.713D), Telerik.Reporting.Drawing.Unit.Inch(2.185D));
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.803D), Telerik.Reporting.Drawing.Unit.Inch(0.173D));
            this.textBox69.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox69.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.Color = System.Drawing.Color.Black;
            this.textBox69.Style.Font.Bold = true;
            this.textBox69.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox69.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox69.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox69.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox69.Value = "";
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(6.352D);
            this.pageFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox49,
            this.textBox50,
            this.textBox51,
            this.textBox52,
            this.Observaciones,
            this.textBox53,
            this.textBox55,
            this.shape31,
            this.shape30,
            this.shape29,
            this.shape28,
            this.shape27,
            this.shape26,
            this.shape25,
            this.shape24,
            this.shape23,
            this.shape22,
            this.shape21,
            this.shape20,
            this.shape43,
            this.shape42,
            this.shape41,
            this.shape40,
            this.shape39,
            this.shape38,
            this.shape37,
            this.shape36,
            this.shape35,
            this.shape34,
            this.shape33,
            this.shape32,
            this.shape19,
            this.shape18,
            this.shape17,
            this.shape16,
            this.shape15,
            this.shape14,
            this.shape13,
            this.shape12,
            this.shape11,
            this.shape10,
            this.shape9,
            this.shape8});
            this.pageFooterSection1.Name = "pageFooterSection1";
            this.pageFooterSection1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            // 
            // textBox49
            // 
            this.textBox49.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.831D), Telerik.Reporting.Drawing.Unit.Cm(9.28D));
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.25D), Telerik.Reporting.Drawing.Unit.Cm(0.47D));
            this.textBox49.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox49.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox49.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox49.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox49.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox49.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox49.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox49.Value = "";
            // 
            // textBox50
            // 
            this.textBox50.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.081D), Telerik.Reporting.Drawing.Unit.Cm(9.28D));
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.25D), Telerik.Reporting.Drawing.Unit.Cm(0.47D));
            this.textBox50.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox50.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox50.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox50.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox50.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox50.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox50.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox50.Value = "";
            // 
            // textBox51
            // 
            this.textBox51.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.331D), Telerik.Reporting.Drawing.Unit.Cm(9.28D));
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.25D), Telerik.Reporting.Drawing.Unit.Cm(0.47D));
            this.textBox51.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox51.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox51.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox51.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox51.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox51.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox51.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox51.Value = "";
            // 
            // textBox52
            // 
            this.textBox52.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.582D), Telerik.Reporting.Drawing.Unit.Cm(9.28D));
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.25D), Telerik.Reporting.Drawing.Unit.Cm(0.47D));
            this.textBox52.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox52.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox52.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox52.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox52.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox52.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox52.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox52.Value = "";
            // 
            // Observaciones
            // 
            this.Observaciones.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.508D), Telerik.Reporting.Drawing.Unit.Cm(10.719D));
            this.Observaciones.Name = "Observaciones";
            this.Observaciones.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.463D), Telerik.Reporting.Drawing.Unit.Cm(1.778D));
            this.Observaciones.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.Observaciones.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.Observaciones.Style.Font.Strikeout = false;
            this.Observaciones.Value = "";
            // 
            // textBox53
            // 
            this.textBox53.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.1D), Telerik.Reporting.Drawing.Unit.Inch(5.22D));
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.369D), Telerik.Reporting.Drawing.Unit.Inch(0.227D));
            this.textBox53.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox53.Style.Font.Bold = false;
            this.textBox53.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox53.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox53.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox53.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox53.Value = "00.00";
            // 
            // textBox55
            // 
            this.textBox55.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.4D), Telerik.Reporting.Drawing.Unit.Inch(5.22D));
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.696D), Telerik.Reporting.Drawing.Unit.Inch(0.228D));
            this.textBox55.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox55.Style.Font.Bold = false;
            this.textBox55.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox55.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox55.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox55.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox55.Value = "";
            // 
            // shape31
            // 
            this.shape31.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(0.63D));
            this.shape31.Name = "shape31";
            this.shape31.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape31.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape31.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape31.Style.Visible = false;
            this.shape31.Value = "X";
            // 
            // shape30
            // 
            this.shape30.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(1.15D));
            this.shape30.Name = "shape30";
            this.shape30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape30.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape30.Style.Visible = false;
            this.shape30.Value = "X";
            // 
            // shape29
            // 
            this.shape29.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(1.67D));
            this.shape29.Name = "shape29";
            this.shape29.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape29.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape29.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape29.Style.Visible = false;
            this.shape29.Value = "X";
            // 
            // shape28
            // 
            this.shape28.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(2.15D));
            this.shape28.Name = "shape28";
            this.shape28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape28.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape28.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape28.Style.Visible = false;
            this.shape28.Value = "X";
            // 
            // shape27
            // 
            this.shape27.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(2.68D));
            this.shape27.Name = "shape27";
            this.shape27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape27.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape27.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape27.Style.Visible = false;
            this.shape27.Value = "X";
            // 
            // shape26
            // 
            this.shape26.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(3.17D));
            this.shape26.Name = "shape26";
            this.shape26.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape26.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape26.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape26.Style.Visible = false;
            this.shape26.Value = "X";
            // 
            // shape25
            // 
            this.shape25.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(3.7D));
            this.shape25.Name = "shape25";
            this.shape25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape25.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape25.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape25.Style.Visible = false;
            this.shape25.Value = "X";
            // 
            // shape24
            // 
            this.shape24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.shape24.Name = "shape24";
            this.shape24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape24.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape24.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape24.Style.Visible = false;
            this.shape24.Value = "X";
            // 
            // shape23
            // 
            this.shape23.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(4.71D));
            this.shape23.Name = "shape23";
            this.shape23.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape23.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape23.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape23.Style.Visible = false;
            this.shape23.Value = "X";
            // 
            // shape22
            // 
            this.shape22.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(5.25D));
            this.shape22.Name = "shape22";
            this.shape22.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape22.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape22.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape22.Style.Visible = false;
            this.shape22.Value = "X";
            // 
            // shape21
            // 
            this.shape21.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(5.71D));
            this.shape21.Name = "shape21";
            this.shape21.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape21.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape21.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape21.Style.Visible = false;
            this.shape21.Value = "X";
            // 
            // shape20
            // 
            this.shape20.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(6.23D));
            this.shape20.Name = "shape20";
            this.shape20.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape20.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape20.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape20.Style.Visible = false;
            this.shape20.Value = "X";
            // 
            // objectDataSource1
            // 
            this.objectDataSource1.CalculatedFields.AddRange(new Telerik.Reporting.CalculatedField[] {
            new Telerik.Reporting.CalculatedField("Field1", typeof(string), "Fields.OrderID"),
            new Telerik.Reporting.CalculatedField("Field2", typeof(string), "Fields.OrderDetailID"),
            new Telerik.Reporting.CalculatedField("Field3", typeof(string), "Fields.ProductID"),
            new Telerik.Reporting.CalculatedField("Field4", typeof(string), "Fields.CodeID"),
            new Telerik.Reporting.CalculatedField("Field5", typeof(string), "Fields.Qty"),
            new Telerik.Reporting.CalculatedField("Field6", typeof(string), "Fields.ProductDescription"),
            new Telerik.Reporting.CalculatedField("Field7", typeof(string), "Fields.UnitPrice"),
            new Telerik.Reporting.CalculatedField("Field8", typeof(string), "Fields.LineTotal"),
            new Telerik.Reporting.CalculatedField("Field9", typeof(string), "Fields.Level"),
            new Telerik.Reporting.CalculatedField("Field10", typeof(string), "Fields.Rampa")});
            this.objectDataSource1.Name = "objectDataSource1";
            // 
            // shape43
            // 
            this.shape43.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(6.98D));
            this.shape43.Name = "shape43";
            this.shape43.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape43.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape43.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape43.Style.Visible = false;
            this.shape43.Value = "X";
            // 
            // shape42
            // 
            this.shape42.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(7.5D));
            this.shape42.Name = "shape42";
            this.shape42.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape42.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape42.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape42.Style.Visible = false;
            this.shape42.Value = "X";
            // 
            // shape41
            // 
            this.shape41.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(8.01D));
            this.shape41.Name = "shape41";
            this.shape41.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape41.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape41.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape41.Style.Visible = false;
            this.shape41.Value = "X";
            // 
            // shape40
            // 
            this.shape40.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(8.51D));
            this.shape40.Name = "shape40";
            this.shape40.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape40.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape40.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape40.Style.Visible = false;
            this.shape40.Value = "X";
            // 
            // shape39
            // 
            this.shape39.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.15D), Telerik.Reporting.Drawing.Unit.Cm(6.98D));
            this.shape39.Name = "shape39";
            this.shape39.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape39.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape39.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape39.Style.Visible = false;
            this.shape39.Value = "X";
            // 
            // shape38
            // 
            this.shape38.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.15D), Telerik.Reporting.Drawing.Unit.Cm(7.5D));
            this.shape38.Name = "shape38";
            this.shape38.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape38.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape38.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape38.Style.Visible = false;
            this.shape38.Value = "X";
            // 
            // shape37
            // 
            this.shape37.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.15D), Telerik.Reporting.Drawing.Unit.Cm(8.05D));
            this.shape37.Name = "shape37";
            this.shape37.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape37.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape37.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape37.Style.Visible = false;
            this.shape37.Value = "X";
            // 
            // shape36
            // 
            this.shape36.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.15D), Telerik.Reporting.Drawing.Unit.Cm(8.55D));
            this.shape36.Name = "shape36";
            this.shape36.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape36.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape36.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape36.Style.Visible = false;
            this.shape36.Value = "X";
            // 
            // shape35
            // 
            this.shape35.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.03D), Telerik.Reporting.Drawing.Unit.Cm(6.98D));
            this.shape35.Name = "shape35";
            this.shape35.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape35.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape35.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape35.Style.Visible = false;
            this.shape35.Value = "X";
            // 
            // shape34
            // 
            this.shape34.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.03D), Telerik.Reporting.Drawing.Unit.Cm(7.5D));
            this.shape34.Name = "shape34";
            this.shape34.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape34.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape34.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape34.Style.Visible = false;
            this.shape34.Value = "X";
            // 
            // shape33
            // 
            this.shape33.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.03D), Telerik.Reporting.Drawing.Unit.Cm(8.05D));
            this.shape33.Name = "shape33";
            this.shape33.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape33.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape33.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape33.Style.Visible = false;
            this.shape33.Value = "X";
            // 
            // shape32
            // 
            this.shape32.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.03D), Telerik.Reporting.Drawing.Unit.Cm(8.55D));
            this.shape32.Name = "shape32";
            this.shape32.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape32.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape32.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape32.Style.Visible = false;
            this.shape32.Value = "X";
            // 
            // shape19
            // 
            this.shape19.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(6.28D));
            this.shape19.Name = "shape19";
            this.shape19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape19.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape19.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape19.Style.Visible = false;
            this.shape19.Value = "X";
            // 
            // shape18
            // 
            this.shape18.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(5.75D));
            this.shape18.Name = "shape18";
            this.shape18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape18.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape18.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape18.Style.Visible = false;
            this.shape18.Value = "X";
            // 
            // shape17
            // 
            this.shape17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(5.25D));
            this.shape17.Name = "shape17";
            this.shape17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape17.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape17.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape17.Style.Visible = false;
            this.shape17.Value = "X";
            // 
            // shape16
            // 
            this.shape16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
            this.shape16.Name = "shape16";
            this.shape16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape16.Style.Visible = false;
            this.shape16.Value = "X";
            // 
            // shape15
            // 
            this.shape15.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.shape15.Name = "shape15";
            this.shape15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape15.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape15.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape15.Style.Visible = false;
            this.shape15.Value = "X";
            // 
            // shape14
            // 
            this.shape14.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(3.69D));
            this.shape14.Name = "shape14";
            this.shape14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape14.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape14.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape14.Style.Visible = false;
            this.shape14.Value = "X";
            // 
            // shape13
            // 
            this.shape13.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(3.19D));
            this.shape13.Name = "shape13";
            this.shape13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape13.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape13.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape13.Style.Visible = false;
            this.shape13.Value = "X";
            // 
            // shape12
            // 
            this.shape12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(2.68D));
            this.shape12.Name = "shape12";
            this.shape12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape12.Style.Visible = false;
            this.shape12.Value = "X";
            // 
            // shape11
            // 
            this.shape11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(2.15D));
            this.shape11.Name = "shape11";
            this.shape11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape11.Style.Visible = false;
            this.shape11.Value = "X";
            // 
            // shape10
            // 
            this.shape10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(1.65D));
            this.shape10.Name = "shape10";
            this.shape10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape10.Style.Visible = false;
            this.shape10.Value = "X";
            // 
            // shape9
            // 
            this.shape9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(1.15D));
            this.shape9.Name = "shape9";
            this.shape9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape9.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape9.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape9.Style.Visible = false;
            this.shape9.Value = "X";
            // 
            // shape8
            // 
            this.shape8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.29D), Telerik.Reporting.Drawing.Unit.Cm(0.63D));
            this.shape8.Name = "shape8";
            this.shape8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape8.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape8.Style.Visible = false;
            this.shape8.Value = "X";
            // 
            // shape5
            // 
            this.shape5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(3.3D));
            this.shape5.Name = "shape5";
            this.shape5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape5.Style.Visible = false;
            this.shape5.Value = "X";
            // 
            // shape6
            // 
            this.shape6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(2.79D));
            this.shape6.Name = "shape6";
            this.shape6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape6.Style.Visible = false;
            this.shape6.Value = "X";
            // 
            // shape7
            // 
            this.shape7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(2.25D));
            this.shape7.Name = "shape7";
            this.shape7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape7.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape7.Style.Visible = false;
            this.shape7.Value = "X";
            // 
            // shape4
            // 
            this.shape4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(1.7D));
            this.shape4.Name = "shape4";
            this.shape4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape4.Style.Visible = false;
            this.shape4.Value = "X";
            // 
            // shape2
            // 
            this.shape2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.shape2.Name = "shape2";
            this.shape2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape2.Style.Visible = false;
            this.shape2.Value = "X";
            // 
            // shape1
            // 
            this.shape1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(0.05D));
            this.shape1.Name = "shape1";
            this.shape1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape1.Style.Visible = false;
            this.shape1.Value = "X";
            // 
            // shape3
            // 
            this.shape3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.92D), Telerik.Reporting.Drawing.Unit.Cm(1.15D));
            this.shape3.Name = "shape3";
            this.shape3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.shape3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.shape3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.shape3.Style.Visible = false;
            this.shape3.Value = "X";
            // 
            // Ordenprint
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1});
            this.Name = "Ordenprint";
            this.PageSettings.ContinuousPaper = false;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Legal;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.UnitOfMeasure = Telerik.Reporting.Drawing.UnitType.Cm;
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(20.5D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.PageFooterSection pageFooterSection1;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox19;
        private Telerik.Reporting.TextBox textBox20;
        private Telerik.Reporting.TextBox textBox21;
        private Telerik.Reporting.TextBox textBox22;
        private Telerik.Reporting.TextBox textBox23;
        private Telerik.Reporting.TextBox textBox24;
        private Telerik.Reporting.TextBox textBox25;
        private Telerik.Reporting.TextBox textBox26;
        private Telerik.Reporting.TextBox textBox27;
        private Telerik.Reporting.TextBox textBox28;
        private Telerik.Reporting.TextBox textBox1;
        private Telerik.Reporting.Table table1;
        private Telerik.Reporting.TextBox textBox90;
        private Telerik.Reporting.TextBox textBox94;
        private Telerik.Reporting.TextBox textBox30;
        private Telerik.Reporting.TextBox textBox32;
        private Telerik.Reporting.TextBox textBox34;
        private Telerik.Reporting.TextBox textBox101;
        private Telerik.Reporting.TextBox textBox68;
        private Telerik.Reporting.TextBox textBox49;
        private Telerik.Reporting.TextBox textBox50;
        private Telerik.Reporting.TextBox textBox51;
        private Telerik.Reporting.TextBox textBox52;
        private Telerik.Reporting.TextBox Observaciones;
        private Telerik.Reporting.TextBox textBox53;
        private Telerik.Reporting.TextBox textBox55;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.ObjectDataSource objectDataSource1;
        private Telerik.Reporting.TextBox textBox92;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox69;
        private Telerik.Reporting.TextBox shape31;
        private Telerik.Reporting.TextBox shape30;
        private Telerik.Reporting.TextBox shape29;
        private Telerik.Reporting.TextBox shape28;
        private Telerik.Reporting.TextBox shape27;
        private Telerik.Reporting.TextBox shape26;
        private Telerik.Reporting.TextBox shape25;
        private Telerik.Reporting.TextBox shape24;
        private Telerik.Reporting.TextBox shape23;
        private Telerik.Reporting.TextBox shape22;
        private Telerik.Reporting.TextBox shape21;
        private Telerik.Reporting.TextBox shape20;
        private Telerik.Reporting.TextBox shape5;
        private Telerik.Reporting.TextBox shape6;
        private Telerik.Reporting.TextBox shape7;
        private Telerik.Reporting.TextBox shape4;
        private Telerik.Reporting.TextBox shape3;
        private Telerik.Reporting.TextBox shape2;
        private Telerik.Reporting.TextBox shape1;
        private Telerik.Reporting.TextBox shape43;
        private Telerik.Reporting.TextBox shape42;
        private Telerik.Reporting.TextBox shape41;
        private Telerik.Reporting.TextBox shape40;
        private Telerik.Reporting.TextBox shape39;
        private Telerik.Reporting.TextBox shape38;
        private Telerik.Reporting.TextBox shape37;
        private Telerik.Reporting.TextBox shape36;
        private Telerik.Reporting.TextBox shape35;
        private Telerik.Reporting.TextBox shape34;
        private Telerik.Reporting.TextBox shape33;
        private Telerik.Reporting.TextBox shape32;
        private Telerik.Reporting.TextBox shape19;
        private Telerik.Reporting.TextBox shape18;
        private Telerik.Reporting.TextBox shape17;
        private Telerik.Reporting.TextBox shape16;
        private Telerik.Reporting.TextBox shape15;
        private Telerik.Reporting.TextBox shape14;
        private Telerik.Reporting.TextBox shape13;
        private Telerik.Reporting.TextBox shape12;
        private Telerik.Reporting.TextBox shape11;
        private Telerik.Reporting.TextBox shape10;
        private Telerik.Reporting.TextBox shape9;
        private Telerik.Reporting.TextBox shape8;
    }
}