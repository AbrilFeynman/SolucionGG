﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GGGC.Admin.AZ.Ordenes.Views
{
  public class GlobalId
    {
        public static string Identificador;

    }
}
