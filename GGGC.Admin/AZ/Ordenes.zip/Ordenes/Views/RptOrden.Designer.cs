namespace GGGC.Admin.AZ.Ordenes.Views
{
	partial class RptOrden
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RptOrden));
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup13 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup14 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup15 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup16 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup17 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup18 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup19 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup20 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup21 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.textBox89 = new Telerik.Reporting.TextBox();
            this.textBox91 = new Telerik.Reporting.TextBox();
            this.textBox29 = new Telerik.Reporting.TextBox();
            this.textBox31 = new Telerik.Reporting.TextBox();
            this.textBox44 = new Telerik.Reporting.TextBox();
            this.textBox33 = new Telerik.Reporting.TextBox();
            this.textBox93 = new Telerik.Reporting.TextBox();
            this.textBox47 = new Telerik.Reporting.TextBox();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.pbxLogo = new Telerik.Reporting.PictureBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox8 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.textBox15 = new Telerik.Reporting.TextBox();
            this.textBox16 = new Telerik.Reporting.TextBox();
            this.textBox17 = new Telerik.Reporting.TextBox();
            this.textBox13 = new Telerik.Reporting.TextBox();
            this.textBox18 = new Telerik.Reporting.TextBox();
            this.textBox19 = new Telerik.Reporting.TextBox();
            this.textBox20 = new Telerik.Reporting.TextBox();
            this.textBox21 = new Telerik.Reporting.TextBox();
            this.textBox22 = new Telerik.Reporting.TextBox();
            this.textBox23 = new Telerik.Reporting.TextBox();
            this.textBox24 = new Telerik.Reporting.TextBox();
            this.textBox25 = new Telerik.Reporting.TextBox();
            this.textBox26 = new Telerik.Reporting.TextBox();
            this.textBox27 = new Telerik.Reporting.TextBox();
            this.textBox28 = new Telerik.Reporting.TextBox();
            this.pictureBox2 = new Telerik.Reporting.PictureBox();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.textBox101 = new Telerik.Reporting.TextBox();
            this.textBox68 = new Telerik.Reporting.TextBox();
            this.textBox71 = new Telerik.Reporting.TextBox();
            this.textBox72 = new Telerik.Reporting.TextBox();
            this.textBox73 = new Telerik.Reporting.TextBox();
            this.table1 = new Telerik.Reporting.Table();
            this.textBox90 = new Telerik.Reporting.TextBox();
            this.textBox92 = new Telerik.Reporting.TextBox();
            this.textBox94 = new Telerik.Reporting.TextBox();
            this.textBox30 = new Telerik.Reporting.TextBox();
            this.textBox32 = new Telerik.Reporting.TextBox();
            this.textBox34 = new Telerik.Reporting.TextBox();
            this.textBox45 = new Telerik.Reporting.TextBox();
            this.objectDataSource1 = new Telerik.Reporting.ObjectDataSource();
            this.textBox69 = new Telerik.Reporting.TextBox();
            this.table2 = new Telerik.Reporting.Table();
            this.textBox48 = new Telerik.Reporting.TextBox();
            this.textBox38 = new Telerik.Reporting.TextBox();
            this.textBox46 = new Telerik.Reporting.TextBox();
            this.textBox35 = new Telerik.Reporting.TextBox();
            this.pllantas = new Telerik.Reporting.CheckBox();
            this.palineacion = new Telerik.Reporting.CheckBox();
            this.pbalanceo = new Telerik.Reporting.CheckBox();
            this.pamorti = new Telerik.Reporting.CheckBox();
            this.psuspen = new Telerik.Reporting.CheckBox();
            this.pfrenos = new Telerik.Reporting.CheckBox();
            this.pcambioaceite = new Telerik.Reporting.CheckBox();
            this.pictureBox3 = new Telerik.Reporting.PictureBox();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            this.textBox70 = new Telerik.Reporting.TextBox();
            this.Caja = new Telerik.Reporting.TextBox();
            this.textBox80 = new Telerik.Reporting.TextBox();
            this.textBox83 = new Telerik.Reporting.TextBox();
            this.textBox84 = new Telerik.Reporting.TextBox();
            this.textBox74 = new Telerik.Reporting.TextBox();
            this.chkbotonesinteriores = new Telerik.Reporting.CheckBox();
            this.chkcinturones = new Telerik.Reporting.CheckBox();
            this.chkcenicero = new Telerik.Reporting.CheckBox();
            this.chkespejoretrovisor = new Telerik.Reporting.CheckBox();
            this.chkencendedor = new Telerik.Reporting.CheckBox();
            this.chkbocinas = new Telerik.Reporting.CheckBox();
            this.chkradio = new Telerik.Reporting.CheckBox();
            this.chkcalefaccion = new Telerik.Reporting.CheckBox();
            this.chkinstrumentostablero = new Telerik.Reporting.CheckBox();
            this.chkcarroseria = new Telerik.Reporting.CheckBox();
            this.chktapongasolina = new Telerik.Reporting.CheckBox();
            this.chkmoldaduras = new Telerik.Reporting.CheckBox();
            this.chktapas = new Telerik.Reporting.CheckBox();
            this.chkemblema = new Telerik.Reporting.CheckBox();
            this.chkcristales = new Telerik.Reporting.CheckBox();
            this.chkespejolateral = new Telerik.Reporting.CheckBox();
            this.chkantena = new Telerik.Reporting.CheckBox();
            this.chkcuartoluces = new Telerik.Reporting.CheckBox();
            this.chkunidadluces = new Telerik.Reporting.CheckBox();
            this.textBox75 = new Telerik.Reporting.TextBox();
            this.pictureBox1 = new Telerik.Reporting.PictureBox();
            this.checkbocinaclaxon = new Telerik.Reporting.CheckBox();
            this.checklimpiaparabrisas = new Telerik.Reporting.CheckBox();
            this.checkmanijasinterior = new Telerik.Reporting.CheckBox();
            this.checktapetes = new Telerik.Reporting.CheckBox();
            this.checkvestiduras = new Telerik.Reporting.CheckBox();
            this.checkgato = new Telerik.Reporting.CheckBox();
            this.checkestucheherramientas = new Telerik.Reporting.CheckBox();
            this.checkclaxon = new Telerik.Reporting.CheckBox();
            this.checkvarillaaceite = new Telerik.Reporting.CheckBox();
            this.checkmaneralgato = new Telerik.Reporting.CheckBox();
            this.checktrianguloseg = new Telerik.Reporting.CheckBox();
            this.checktaponaceite = new Telerik.Reporting.CheckBox();
            this.checkfiltroaire = new Telerik.Reporting.CheckBox();
            this.checkllaverueda = new Telerik.Reporting.CheckBox();
            this.checkllantarefaccion = new Telerik.Reporting.CheckBox();
            this.checktaponradiador = new Telerik.Reporting.CheckBox();
            this.checkbateriamca = new Telerik.Reporting.CheckBox();
            this.textBox49 = new Telerik.Reporting.TextBox();
            this.textBox50 = new Telerik.Reporting.TextBox();
            this.textBox51 = new Telerik.Reporting.TextBox();
            this.textBox52 = new Telerik.Reporting.TextBox();
            this.Observaciones = new Telerik.Reporting.TextBox();
            this.textBox53 = new Telerik.Reporting.TextBox();
            this.textBox54 = new Telerik.Reporting.TextBox();
            this.textBox55 = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // textBox89
            // 
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0233645439147949D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox89.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox89.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox89.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox89.Style.Font.Bold = true;
            this.textBox89.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox89.Style.Font.Strikeout = false;
            this.textBox89.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox89.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox89.Value = "C�DIGO:";
            // 
            // textBox91
            // 
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.5772733688354492D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox91.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox91.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox91.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox91.Style.Font.Bold = true;
            this.textBox91.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox91.Style.Font.Strikeout = false;
            this.textBox91.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox91.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox91.Value = "DESCRIPCI�N";
            // 
            // textBox29
            // 
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5827028751373291D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox29.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox29.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox29.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox29.Style.Font.Bold = true;
            this.textBox29.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox29.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox29.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox29.StyleName = "";
            this.textBox29.Value = "CANTIDAD:";
            // 
            // textBox31
            // 
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4339501857757568D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox31.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox31.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox31.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox31.Style.Font.Bold = true;
            this.textBox31.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox31.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox31.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox31.StyleName = "";
            this.textBox31.Value = "NO. RAMPA";
            // 
            // textBox44
            // 
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3650000095367432D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox44.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox44.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox44.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox44.Style.Font.Bold = true;
            this.textBox44.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox44.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox44.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox44.StyleName = "";
            this.textBox44.Value = "NIVEL P.";
            // 
            // textBox33
            // 
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0852105617523193D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox33.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox33.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox33.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox33.Style.Font.Bold = true;
            this.textBox33.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox33.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox33.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox33.StyleName = "";
            this.textBox33.Value = "P. VENTA";
            // 
            // textBox93
            // 
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0533323287963867D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox93.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox93.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox93.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox93.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox93.Style.Font.Bold = true;
            this.textBox93.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox93.Style.Font.Strikeout = false;
            this.textBox93.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox93.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox93.StyleName = "";
            this.textBox93.Value = "IMPORTE";
            // 
            // textBox47
            // 
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.43656259775161743D));
            this.textBox47.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox47.Style.Font.Bold = true;
            this.textBox47.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.textBox47.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox47.Value = "Servicios pendientes";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(2.9047391414642334D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pbxLogo,
            this.textBox2,
            this.textBox3,
            this.textBox4,
            this.textBox5,
            this.textBox6,
            this.textBox7,
            this.textBox8,
            this.textBox9,
            this.textBox10,
            this.textBox11,
            this.textBox12,
            this.textBox14,
            this.textBox15,
            this.textBox16,
            this.textBox17,
            this.textBox13,
            this.textBox18,
            this.textBox19,
            this.textBox20,
            this.textBox21,
            this.textBox22,
            this.textBox23,
            this.textBox24,
            this.textBox25,
            this.textBox26,
            this.textBox27,
            this.textBox28,
            this.pictureBox2,
            this.textBox1});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            this.pageHeaderSection1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.pageHeaderSection1.Style.Font.Strikeout = false;
            this.pageHeaderSection1.Style.LineColor = System.Drawing.Color.Blue;
            this.pageHeaderSection1.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.pageHeaderSection1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            // 
            // pbxLogo
            // 
            this.pbxLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.37041664123535156D), Telerik.Reporting.Drawing.Unit.Cm(9.9921220680698752E-05D));
            this.pbxLogo.MimeType = "image/png";
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(19.700000762939453D), Telerik.Reporting.Drawing.Unit.Cm(2.5113542079925537D));
            this.pbxLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pbxLogo.Value = ((object)(resources.GetObject("pbxLogo.Value")));
            // 
            // textBox2
            // 
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34395831823349D), Telerik.Reporting.Drawing.Unit.Cm(2.6061458587646484D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8000001907348633D), Telerik.Reporting.Drawing.Unit.Cm(0.49000000953674316D));
            this.textBox2.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox2.Style.LineColor = System.Drawing.Color.Blue;
            this.textBox2.Value = "";
            // 
            // textBox3
            // 
            this.textBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.133437156677246D), Telerik.Reporting.Drawing.Unit.Cm(2.6044025421142578D));
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.9393749237060547D), Telerik.Reporting.Drawing.Unit.Cm(0.49000000953674316D));
            this.textBox3.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox3.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox3.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox3.Style.LineColor = System.Drawing.Color.Black;
            this.textBox3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox3.Value = "R.F.C. LRG9205022BG7";
            // 
            // textBox4
            // 
            this.textBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34500002861022949D), Telerik.Reporting.Drawing.Unit.Cm(3.0855214595794678D));
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8100004196167D), Telerik.Reporting.Drawing.Unit.Cm(0.56483334302902222D));
            this.textBox4.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox4.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox4.Style.LineColor = System.Drawing.Color.Black;
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox4.Value = "Llantas y Rines del Guadiana S.A. de C.V.";
            // 
            // textBox5
            // 
            this.textBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.150458335876465D), Telerik.Reporting.Drawing.Unit.Cm(3.0881664752960205D));
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.9158334732055664D), Telerik.Reporting.Drawing.Unit.Cm(0.56483334302902222D));
            this.textBox5.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox5.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox5.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox5.Style.LineColor = System.Drawing.Color.Black;
            this.textBox5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox5.Value = "";
            // 
            // textBox6
            // 
            this.textBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34764590859413147D), Telerik.Reporting.Drawing.Unit.Cm(3.6437914371490479D));
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(19.719999313354492D), Telerik.Reporting.Drawing.Unit.Cm(3.07277774810791D));
            this.textBox6.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox6.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox6.Style.Color = System.Drawing.Color.Blue;
            this.textBox6.Style.LineColor = System.Drawing.Color.Black;
            this.textBox6.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox6.Value = "";
            // 
            // textBox7
            // 
            this.textBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.7067084312438965D), Telerik.Reporting.Drawing.Unit.Cm(3.753572940826416D));
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6196870803833008D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox7.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox7.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox7.Style.Color = System.Drawing.Color.Black;
            this.textBox7.Style.LineColor = System.Drawing.Color.Black;
            this.textBox7.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox7.Value = "";
            // 
            // textBox8
            // 
            this.textBox8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.54872918128967285D), Telerik.Reporting.Drawing.Unit.Cm(4.5680651664733887D));
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6268750429153442D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox8.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox8.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox8.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox8.Style.LineColor = System.Drawing.Color.Black;
            this.textBox8.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox8.Value = "Direcci�n:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.56460416316986084D), Telerik.Reporting.Drawing.Unit.Cm(5.360051155090332D));
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.1770833730697632D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox9.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox9.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox9.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox9.Style.LineColor = System.Drawing.Color.Black;
            this.textBox9.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox9.Value = "R.F.C.";
            // 
            // textBox10
            // 
            this.textBox10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.54872918128967285D), Telerik.Reporting.Drawing.Unit.Cm(6.1026644706726074D));
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5475000143051148D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox10.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox10.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox10.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox10.Style.LineColor = System.Drawing.Color.Black;
            this.textBox10.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox10.Value = "T�lefono:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.941686630249023D), Telerik.Reporting.Drawing.Unit.Cm(4.1914792060852051D));
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.87583327293396D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox11.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox11.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox11.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox11.Style.LineColor = System.Drawing.Color.Black;
            this.textBox11.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox11.Value = "Fecha Y Hora de Entrega:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.556276321411133D), Telerik.Reporting.Drawing.Unit.Cm(3.7707920074462891D));
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.2638888359069824D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox12.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox12.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox12.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox12.Style.LineColor = System.Drawing.Color.Black;
            this.textBox12.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox12.Value = "Fecha Y Hora de Recepci�n:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.524904251098633D), Telerik.Reporting.Drawing.Unit.Cm(5.0196256637573242D));
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3005555868148804D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox14.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox14.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox14.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox14.Style.LineColor = System.Drawing.Color.Black;
            this.textBox14.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox14.Value = "Modelo:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.668658256530762D), Telerik.Reporting.Drawing.Unit.Cm(4.5989384651184082D));
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.1418055295944214D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox15.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox15.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox15.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox15.Style.LineColor = System.Drawing.Color.Black;
            this.textBox15.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox15.Value = "Marca:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.971165657043457D), Telerik.Reporting.Drawing.Unit.Cm(6.2552299499511719D));
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.85958337783813477D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox16.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox16.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox16.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox16.Style.LineColor = System.Drawing.Color.Black;
            this.textBox16.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox16.Value = "Km.:";
            // 
            // textBox17
            // 
            this.textBox17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.991452217102051D), Telerik.Reporting.Drawing.Unit.Cm(5.4244384765625D));
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.84194445610046387D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox17.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox17.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox17.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox17.Style.LineColor = System.Drawing.Color.Black;
            this.textBox17.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox17.Value = "A�o:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.604999542236328D), Telerik.Reporting.Drawing.Unit.Cm(5.8340620994567871D));
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2300000190734863D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox13.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox13.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox13.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox13.Style.LineColor = System.Drawing.Color.Black;
            this.textBox13.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox13.Value = "Placas:";
            // 
            // textBox18
            // 
            this.textBox18.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.53435426950454712D), Telerik.Reporting.Drawing.Unit.Cm(3.7562189102172852D));
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0027084350585938D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox18.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox18.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox18.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox18.Style.LineColor = System.Drawing.Color.Black;
            this.textBox18.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox18.Value = "Nombre del cliente:";
            // 
            // textBox19
            // 
            this.textBox19.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.3743541240692139D), Telerik.Reporting.Drawing.Unit.Cm(4.5680651664733887D));
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.482604026794434D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox19.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox19.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox19.Style.Color = System.Drawing.Color.Black;
            this.textBox19.Style.LineColor = System.Drawing.Color.Black;
            this.textBox19.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox19.Value = "";
            // 
            // textBox20
            // 
            this.textBox20.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.8981044292449951D), Telerik.Reporting.Drawing.Unit.Cm(5.3574051856994629D));
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.8469791412353516D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox20.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox20.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox20.Style.Color = System.Drawing.Color.Black;
            this.textBox20.Style.LineColor = System.Drawing.Color.Black;
            this.textBox20.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox20.Value = "";
            // 
            // textBox21
            // 
            this.textBox21.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.2552919387817383D), Telerik.Reporting.Drawing.Unit.Cm(6.1026644706726074D));
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4633331298828125D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox21.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox21.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox21.Style.Color = System.Drawing.Color.Black;
            this.textBox21.Style.LineColor = System.Drawing.Color.Black;
            this.textBox21.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox21.Value = "";
            // 
            // textBox22
            // 
            this.textBox22.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.902498245239258D), Telerik.Reporting.Drawing.Unit.Cm(3.76020884513855D));
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.1271877288818359D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox22.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox22.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox22.Style.Color = System.Drawing.Color.Black;
            this.textBox22.Style.LineColor = System.Drawing.Color.Black;
            this.textBox22.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox22.Value = "";
            // 
            // textBox23
            // 
            this.textBox23.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.91837215423584D), Telerik.Reporting.Drawing.Unit.Cm(4.1729588508605957D));
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.1227779388427734D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox23.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox23.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox23.Style.Color = System.Drawing.Color.Black;
            this.textBox23.Style.LineColor = System.Drawing.Color.Black;
            this.textBox23.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox23.Value = "";
            // 
            // textBox24
            // 
            this.textBox24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.894558906555176D), Telerik.Reporting.Drawing.Unit.Cm(4.5857095718383789D));
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6641666889190674D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox24.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox24.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox24.Style.Color = System.Drawing.Color.Black;
            this.textBox24.Style.LineColor = System.Drawing.Color.Black;
            this.textBox24.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox24.Value = "";
            // 
            // textBox25
            // 
            this.textBox25.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.907791137695313D), Telerik.Reporting.Drawing.Unit.Cm(4.995811939239502D));
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6641666889190674D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox25.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox25.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox25.Style.Color = System.Drawing.Color.Black;
            this.textBox25.Style.LineColor = System.Drawing.Color.Black;
            this.textBox25.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox25.Value = "";
            // 
            // textBox26
            // 
            this.textBox26.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.897207260131836D), Telerik.Reporting.Drawing.Unit.Cm(5.4085626602172852D));
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6641666889190674D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox26.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox26.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox26.Style.Color = System.Drawing.Color.Black;
            this.textBox26.Style.LineColor = System.Drawing.Color.Black;
            this.textBox26.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox26.Value = "";
            // 
            // textBox27
            // 
            this.textBox27.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.913082122802734D), Telerik.Reporting.Drawing.Unit.Cm(5.82131290435791D));
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6641666889190674D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox27.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox27.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox27.Style.Color = System.Drawing.Color.Black;
            this.textBox27.Style.LineColor = System.Drawing.Color.Black;
            this.textBox27.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox27.Value = "";
            // 
            // textBox28
            // 
            this.textBox28.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.928956031799316D), Telerik.Reporting.Drawing.Unit.Cm(6.2472915649414062D));
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6641666889190674D), Telerik.Reporting.Drawing.Unit.Cm(0.39812499284744263D));
            this.textBox28.Style.BorderColor.Default = System.Drawing.Color.Blue;
            this.textBox28.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox28.Style.Color = System.Drawing.Color.Black;
            this.textBox28.Style.LineColor = System.Drawing.Color.Black;
            this.textBox28.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox28.Value = "";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.32455575466156006D), Telerik.Reporting.Drawing.Unit.Cm(6.69671630859375D));
            this.pictureBox2.MimeType = "image/png";
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(19.80583381652832D), Telerik.Reporting.Drawing.Unit.Cm(0.67250007390975952D));
            this.pictureBox2.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pictureBox2.Value = ((object)(resources.GetObject("pictureBox2.Value")));
            // 
            // textBox1
            // 
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.42520809173584D), Telerik.Reporting.Drawing.Unit.Cm(0.87312495708465576D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.60000002384185791D));
            this.textBox1.Value = "textBox1";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Inch(2.0499999523162842D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox101,
            this.textBox68,
            this.textBox71,
            this.textBox72,
            this.textBox73,
            this.table1,
            this.textBox69,
            this.table2});
            this.detail.Name = "detail";
            this.detail.Style.Color = System.Drawing.Color.LightSeaGreen;
            this.detail.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            // 
            // textBox101
            // 
            this.textBox101.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(7.111055850982666D), Telerik.Reporting.Drawing.Unit.Inch(0.49960550665855408D));
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.80324995517730713D), Telerik.Reporting.Drawing.Unit.Inch(0.17703640460968018D));
            this.textBox101.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox101.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox101.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox101.Style.Color = System.Drawing.Color.Black;
            this.textBox101.Style.Font.Bold = true;
            this.textBox101.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox101.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox101.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox101.Value = "";
            // 
            // textBox68
            // 
            this.textBox68.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(7.111055850982666D), Telerik.Reporting.Drawing.Unit.Inch(0.67672061920166016D));
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.80324995517730713D), Telerik.Reporting.Drawing.Unit.Inch(0.17703640460968018D));
            this.textBox68.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox68.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox68.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox68.Style.Color = System.Drawing.Color.Black;
            this.textBox68.Style.Font.Bold = true;
            this.textBox68.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox68.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox68.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox68.Value = "";
            // 
            // textBox71
            // 
            this.textBox71.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.5583724975585938D), Telerik.Reporting.Drawing.Unit.Inch(0.50325107574462891D));
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.54262912273406982D), Telerik.Reporting.Drawing.Unit.Inch(0.17703646421432495D));
            this.textBox71.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox71.Style.Font.Bold = true;
            this.textBox71.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox71.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox71.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox71.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox71.Value = "SUB-TOTAL";
            // 
            // textBox72
            // 
            this.textBox72.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.5583724975585938D), Telerik.Reporting.Drawing.Unit.Inch(0.68453311920166016D));
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.55304580926895142D), Telerik.Reporting.Drawing.Unit.Inch(0.17703646421432495D));
            this.textBox72.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox72.Style.Font.Bold = true;
            this.textBox72.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox72.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox72.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox72.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox72.Value = "IVA";
            // 
            // textBox73
            // 
            this.textBox73.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.1666274070739746D), Telerik.Reporting.Drawing.Unit.Inch(0.85643988847732544D));
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.94891816377639771D), Telerik.Reporting.Drawing.Unit.Inch(0.17703646421432495D));
            this.textBox73.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox73.Style.Font.Bold = true;
            this.textBox73.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox73.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox73.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox73.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox73.Value = "PRECIO TOTAL";
            // 
            // table1
            // 
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.0233633518218994D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.5772724151611328D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.5827012062072754D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.4339499473571777D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.3649992942810059D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.085209846496582D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.0533325672149658D)));
            this.table1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D)));
            this.table1.Body.SetCellContent(0, 0, this.textBox90);
            this.table1.Body.SetCellContent(0, 1, this.textBox92);
            this.table1.Body.SetCellContent(0, 6, this.textBox94);
            this.table1.Body.SetCellContent(0, 2, this.textBox30);
            this.table1.Body.SetCellContent(0, 3, this.textBox32);
            this.table1.Body.SetCellContent(0, 5, this.textBox34);
            this.table1.Body.SetCellContent(0, 4, this.textBox45);
            tableGroup1.Name = "tableGroup1";
            tableGroup1.ReportItem = this.textBox89;
            tableGroup2.Name = "tableGroup2";
            tableGroup2.ReportItem = this.textBox91;
            tableGroup3.Name = "group1";
            tableGroup3.ReportItem = this.textBox29;
            tableGroup4.Name = "group2";
            tableGroup4.ReportItem = this.textBox31;
            tableGroup5.Name = "group4";
            tableGroup5.ReportItem = this.textBox44;
            tableGroup6.Name = "group3";
            tableGroup6.ReportItem = this.textBox33;
            tableGroup7.Name = "group";
            tableGroup7.ReportItem = this.textBox93;
            this.table1.ColumnGroups.Add(tableGroup1);
            this.table1.ColumnGroups.Add(tableGroup2);
            this.table1.ColumnGroups.Add(tableGroup3);
            this.table1.ColumnGroups.Add(tableGroup4);
            this.table1.ColumnGroups.Add(tableGroup5);
            this.table1.ColumnGroups.Add(tableGroup6);
            this.table1.ColumnGroups.Add(tableGroup7);
            this.table1.DataSource = this.objectDataSource1;
            this.table1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox90,
            this.textBox92,
            this.textBox30,
            this.textBox32,
            this.textBox45,
            this.textBox34,
            this.textBox94,
            this.textBox89,
            this.textBox91,
            this.textBox29,
            this.textBox31,
            this.textBox44,
            this.textBox33,
            this.textBox93});
            this.table1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.9952082633972168D), Telerik.Reporting.Drawing.Unit.Cm(0.029424075037240982D));
            this.table1.Name = "table1";
            tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup8.Name = "detailTableGroup";
            this.table1.RowGroups.Add(tableGroup8);
            this.table1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.120828628540039D), Telerik.Reporting.Drawing.Unit.Cm(1.2200000286102295D));
            this.table1.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.table1.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.table1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            this.table1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.table1.Style.Color = System.Drawing.Color.DarkBlue;
            this.table1.Style.LineColor = System.Drawing.Color.Gold;
            this.table1.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(2D);
            // 
            // textBox90
            // 
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0233645439147949D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox90.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox90.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox90.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox90.Style.Color = System.Drawing.Color.Black;
            this.textBox90.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox90.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox90.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox90.Value = "= Fields.Field4";
            // 
            // textBox92
            // 
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.5772733688354492D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox92.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox92.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox92.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox92.Style.Color = System.Drawing.Color.Black;
            this.textBox92.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox92.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox92.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox92.Value = "= Fields.Field6";
            // 
            // textBox94
            // 
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0533323287963867D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox94.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox94.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox94.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox94.Style.Color = System.Drawing.Color.Black;
            this.textBox94.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox94.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox94.StyleName = "";
            this.textBox94.Value = "= Fields.Field8";
            // 
            // textBox30
            // 
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5827028751373291D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox30.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox30.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox30.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox30.Style.Color = System.Drawing.Color.Black;
            this.textBox30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox30.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox30.StyleName = "";
            this.textBox30.Value = "= Fields.Field5";
            // 
            // textBox32
            // 
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4339501857757568D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox32.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox32.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox32.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox32.Style.Color = System.Drawing.Color.Black;
            this.textBox32.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox32.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox32.StyleName = "";
            this.textBox32.Value = "= Fields.Field10";
            // 
            // textBox34
            // 
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0852105617523193D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox34.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox34.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox34.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox34.Style.Color = System.Drawing.Color.Black;
            this.textBox34.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox34.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox34.StyleName = "";
            this.textBox34.Value = "= Fields.Field7";
            // 
            // textBox45
            // 
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3650000095367432D), Telerik.Reporting.Drawing.Unit.Cm(0.61000001430511475D));
            this.textBox45.Style.BorderColor.Bottom = System.Drawing.Color.Transparent;
            this.textBox45.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox45.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox45.Style.Color = System.Drawing.Color.Black;
            this.textBox45.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox45.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox45.StyleName = "";
            this.textBox45.Value = "= Fields.Field9";
            // 
            // objectDataSource1
            // 
            this.objectDataSource1.CalculatedFields.AddRange(new Telerik.Reporting.CalculatedField[] {
            new Telerik.Reporting.CalculatedField("Field1", typeof(string), "Fields.OrderID"),
            new Telerik.Reporting.CalculatedField("Field2", typeof(string), "Fields.OrderDetailID"),
            new Telerik.Reporting.CalculatedField("Field3", typeof(string), "Fields.ProductID"),
            new Telerik.Reporting.CalculatedField("Field4", typeof(string), "Fields.CodeID"),
            new Telerik.Reporting.CalculatedField("Field5", typeof(string), "Fields.Qty"),
            new Telerik.Reporting.CalculatedField("Field6", typeof(string), "Fields.ProductDescription"),
            new Telerik.Reporting.CalculatedField("Field7", typeof(string), "Fields.UnitPrice"),
            new Telerik.Reporting.CalculatedField("Field8", typeof(string), "Fields.LineTotal"),
            new Telerik.Reporting.CalculatedField("Field9", typeof(string), "Fields.Level"),
            new Telerik.Reporting.CalculatedField("Field10", typeof(string), "Fields.Rampa")});
            this.objectDataSource1.Name = "objectDataSource1";
            // 
            // textBox69
            // 
            this.textBox69.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(7.1197915077209473D), Telerik.Reporting.Drawing.Unit.Inch(0.85677117109298706D));
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.79283326864242554D), Telerik.Reporting.Drawing.Unit.Inch(0.17703640460968018D));
            this.textBox69.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox69.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox69.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox69.Style.Color = System.Drawing.Color.Black;
            this.textBox69.Style.Font.Bold = true;
            this.textBox69.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox69.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox69.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox69.Value = "";
            // 
            // table2
            // 
            this.table2.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.51593804359436035D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.63229167461395264D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.31479179859161377D)));
            this.table2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D)));
            this.table2.Body.SetCellContent(9, 0, this.textBox48);
            this.table2.Body.SetCellContent(10, 0, this.textBox38);
            this.table2.Body.SetCellContent(8, 0, this.textBox46);
            this.table2.Body.SetCellContent(7, 0, this.textBox35);
            this.table2.Body.SetCellContent(0, 0, this.pllantas);
            this.table2.Body.SetCellContent(1, 0, this.palineacion);
            this.table2.Body.SetCellContent(2, 0, this.pbalanceo);
            this.table2.Body.SetCellContent(3, 0, this.pamorti);
            this.table2.Body.SetCellContent(4, 0, this.psuspen);
            this.table2.Body.SetCellContent(5, 0, this.pfrenos);
            this.table2.Body.SetCellContent(6, 0, this.pcambioaceite);
            tableGroup9.Name = "tableGroup";
            tableGroup9.ReportItem = this.textBox47;
            this.table2.ColumnGroups.Add(tableGroup9);
            this.table2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pllantas,
            this.palineacion,
            this.pbalanceo,
            this.pamorti,
            this.psuspen,
            this.pfrenos,
            this.pcambioaceite,
            this.textBox35,
            this.textBox46,
            this.textBox48,
            this.textBox38,
            this.textBox47});
            this.table2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.37041664123535156D), Telerik.Reporting.Drawing.Unit.Cm(0.078817054629325867D));
            this.table2.Name = "table2";
            tableGroup11.Name = "group5";
            tableGroup12.Name = "group6";
            tableGroup13.Name = "group7";
            tableGroup14.Name = "group8";
            tableGroup15.Name = "group9";
            tableGroup16.Name = "group10";
            tableGroup17.Name = "group11";
            tableGroup18.Name = "group16";
            tableGroup19.Name = "group15";
            tableGroup20.Name = "group13";
            tableGroup21.Name = "group14";
            tableGroup10.ChildGroups.Add(tableGroup11);
            tableGroup10.ChildGroups.Add(tableGroup12);
            tableGroup10.ChildGroups.Add(tableGroup13);
            tableGroup10.ChildGroups.Add(tableGroup14);
            tableGroup10.ChildGroups.Add(tableGroup15);
            tableGroup10.ChildGroups.Add(tableGroup16);
            tableGroup10.ChildGroups.Add(tableGroup17);
            tableGroup10.ChildGroups.Add(tableGroup18);
            tableGroup10.ChildGroups.Add(tableGroup19);
            tableGroup10.ChildGroups.Add(tableGroup20);
            tableGroup10.ChildGroups.Add(tableGroup21);
            tableGroup10.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup10.Name = "detailTableGroup1";
            this.table2.RowGroups.Add(tableGroup10);
            this.table2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(5.8995847702026367D));
            // 
            // textBox48
            // 
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.31479164958000183D));
            this.textBox48.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox48.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox48.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox48.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox48.StyleName = "";
            // 
            // textBox38
            // 
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.49999997019767761D));
            this.textBox38.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox38.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox38.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox38.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox38.Style.LineColor = System.Drawing.Color.Black;
            this.textBox38.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox38.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox38.StyleName = "";
            this.textBox38.Value = "Firma(s) mec�nico(s)";
            // 
            // textBox46
            // 
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox46.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox46.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox46.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox46.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox46.StyleName = "";
            // 
            // textBox35
            // 
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.63229173421859741D));
            this.textBox35.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox35.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox35.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox35.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox35.StyleName = "";
            // 
            // pllantas
            // 
            this.pllantas.FalseValue = "False";
            this.pllantas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.2863011360168457D), Telerik.Reporting.Drawing.Unit.Inch(0.59612149000167847D));
            this.pllantas.Name = "pllantas";
            this.pllantas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.51593798398971558D));
            this.pllantas.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.pllantas.Style.Color = System.Drawing.Color.DarkBlue;
            this.pllantas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.pllantas.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.pllantas.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.pllantas.StyleName = "";
            this.pllantas.Text = "LLANTAS";
            this.pllantas.TrueValue = "= True";
            this.pllantas.Value = "False";
            // 
            // palineacion
            // 
            this.palineacion.FalseValue = "False";
            this.palineacion.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(4.0390787124633789D), Telerik.Reporting.Drawing.Unit.Inch(0.59889942407608032D));
            this.palineacion.Name = "palineacion";
            this.palineacion.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.palineacion.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.palineacion.Style.Color = System.Drawing.Color.DarkBlue;
            this.palineacion.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.palineacion.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.palineacion.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.palineacion.StyleName = "";
            this.palineacion.Text = "ALINEACI�N";
            this.palineacion.TrueValue = "= True";
            this.palineacion.Value = "False";
            // 
            // pbalanceo
            // 
            this.pbalanceo.FalseValue = "False";
            this.pbalanceo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(1.9071344137191773D), Telerik.Reporting.Drawing.Unit.Inch(0.56417721509933472D));
            this.pbalanceo.Name = "pbalanceo";
            this.pbalanceo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.pbalanceo.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.pbalanceo.Style.Color = System.Drawing.Color.DarkBlue;
            this.pbalanceo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.pbalanceo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.pbalanceo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.pbalanceo.StyleName = "";
            this.pbalanceo.Text = "BALANCEO";
            this.pbalanceo.TrueValue = "= True";
            this.pbalanceo.Value = "False";
            // 
            // pamorti
            // 
            this.pamorti.FalseValue = "False";
            this.pamorti.Name = "pamorti";
            this.pamorti.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.pamorti.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.pamorti.Style.Color = System.Drawing.Color.DarkBlue;
            this.pamorti.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.pamorti.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.pamorti.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.pamorti.StyleName = "";
            this.pamorti.Text = "AMORTIGUADORES";
            this.pamorti.TrueValue = "= True";
            this.pamorti.Value = "False";
            // 
            // psuspen
            // 
            this.psuspen.FalseValue = "False";
            this.psuspen.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.0182452201843262D), Telerik.Reporting.Drawing.Unit.Inch(0.65445494651794434D));
            this.psuspen.Name = "psuspen";
            this.psuspen.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.psuspen.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.psuspen.Style.Color = System.Drawing.Color.DarkBlue;
            this.psuspen.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.psuspen.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.psuspen.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.psuspen.StyleName = "";
            this.psuspen.Text = "SUSPENCI�N";
            this.psuspen.TrueValue = "= True";
            this.psuspen.Value = "False";
            // 
            // pfrenos
            // 
            this.pfrenos.FalseValue = "False";
            this.pfrenos.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.5501899719238281D), Telerik.Reporting.Drawing.Unit.Inch(0.88084369897842407D));
            this.pfrenos.Name = "pfrenos";
            this.pfrenos.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.pfrenos.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.pfrenos.Style.Color = System.Drawing.Color.DarkBlue;
            this.pfrenos.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.pfrenos.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.pfrenos.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.pfrenos.StyleName = "";
            this.pfrenos.Text = "FRENOS";
            this.pfrenos.TrueValue = "= True";
            this.pfrenos.Value = "False";
            // 
            // pcambioaceite
            // 
            this.pcambioaceite.FalseValue = "False";
            this.pcambioaceite.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.2849118709564209D), Telerik.Reporting.Drawing.Unit.Inch(1.2336218357086182D));
            this.pcambioaceite.Name = "pcambioaceite";
            this.pcambioaceite.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5233681201934814D), Telerik.Reporting.Drawing.Unit.Cm(0.50000005960464478D));
            this.pcambioaceite.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.pcambioaceite.Style.Color = System.Drawing.Color.DarkBlue;
            this.pcambioaceite.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.pcambioaceite.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.pcambioaceite.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.pcambioaceite.StyleName = "";
            this.pcambioaceite.Text = "CAMBIO DE ACEITE";
            this.pcambioaceite.TrueValue = "= True";
            this.pcambioaceite.Value = "False";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.3307291567325592D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.pictureBox3.MimeType = "image/png";
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(19.809999465942383D), Telerik.Reporting.Drawing.Unit.Cm(0.67000001668930054D));
            this.pictureBox3.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pictureBox3.Value = ((object)(resources.GetObject("pictureBox3.Value")));
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Inch(5.2300000190734863D);
            this.pageFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox70,
            this.Caja,
            this.textBox80,
            this.textBox83,
            this.textBox84,
            this.textBox74,
            this.chkbotonesinteriores,
            this.chkcinturones,
            this.chkcenicero,
            this.chkespejoretrovisor,
            this.chkencendedor,
            this.chkbocinas,
            this.chkradio,
            this.chkcalefaccion,
            this.chkinstrumentostablero,
            this.chkcarroseria,
            this.chktapongasolina,
            this.chkmoldaduras,
            this.chktapas,
            this.chkemblema,
            this.chkcristales,
            this.chkespejolateral,
            this.chkantena,
            this.chkcuartoluces,
            this.chkunidadluces,
            this.textBox75,
            this.pictureBox1,
            this.checkbocinaclaxon,
            this.checklimpiaparabrisas,
            this.pictureBox3,
            this.checkmanijasinterior,
            this.checktapetes,
            this.checkvestiduras,
            this.checkgato,
            this.checkestucheherramientas,
            this.checkclaxon,
            this.checkvarillaaceite,
            this.checkmaneralgato,
            this.checktrianguloseg,
            this.checktaponaceite,
            this.checkfiltroaire,
            this.checkllaverueda,
            this.checkllantarefaccion,
            this.checktaponradiador,
            this.checkbateriamca,
            this.textBox49,
            this.textBox50,
            this.textBox51,
            this.textBox52,
            this.Observaciones,
            this.textBox53,
            this.textBox54,
            this.textBox55});
            this.pageFooterSection1.Name = "pageFooterSection1";
            // 
            // textBox70
            // 
            this.textBox70.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(5.2015624046325684D), Telerik.Reporting.Drawing.Unit.Inch(3.359375D));
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.69563579559326172D), Telerik.Reporting.Drawing.Unit.Inch(0.14578646421432495D));
            this.textBox70.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox70.Style.Font.Bold = true;
            this.textBox70.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox70.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox70.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox70.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox70.Value = "GASOLINA";
            // 
            // Caja
            // 
            this.Caja.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.39375051856040955D), Telerik.Reporting.Drawing.Unit.Inch(3.5370883941650391D));
            this.Caja.Name = "Caja";
            this.Caja.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(7.2340970039367676D), Telerik.Reporting.Drawing.Unit.Inch(0.57496845722198486D));
            this.Caja.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.Caja.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Caja.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Caja.Style.Color = System.Drawing.Color.DarkBlue;
            this.Caja.Style.Font.Bold = true;
            this.Caja.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.Caja.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.Caja.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.Caja.Value = "OBSERVACIONES";
            // 
            // textBox80
            // 
            this.textBox80.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.3958333432674408D), Telerik.Reporting.Drawing.Unit.Inch(4.1312332153320312D));
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(7.2215986251831055D), Telerik.Reporting.Drawing.Unit.Inch(0.29992121458053589D));
            this.textBox80.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox80.Style.Font.Bold = false;
            this.textBox80.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox80.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox80.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox80.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox80.Value = resources.GetString("textBox80.Value");
            // 
            // textBox83
            // 
            this.textBox83.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(1.6250008344650269D), Telerik.Reporting.Drawing.Unit.Inch(4.8158774375915527D));
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(2.1999993324279785D), Telerik.Reporting.Drawing.Unit.Inch(0.29992121458053589D));
            this.textBox83.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox83.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox83.Style.Font.Bold = false;
            this.textBox83.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox83.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox83.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox83.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox83.Value = "FIRMA DEL PRESTADOR DEL SERVICIO";
            // 
            // textBox84
            // 
            this.textBox84.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(4.5230355262756348D), Telerik.Reporting.Drawing.Unit.Inch(4.8158774375915527D));
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(2.301964282989502D), Telerik.Reporting.Drawing.Unit.Inch(0.33464342355728149D));
            this.textBox84.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox84.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox84.Style.Font.Bold = false;
            this.textBox84.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox84.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox84.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox84.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox84.Value = "FECHA Y FIRMA DEL CONSUMIDOR ACEPTANDO EL PRESUPUESTO";
            // 
            // textBox74
            // 
            this.textBox74.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.63420200347900391D), Telerik.Reporting.Drawing.Unit.Inch(0.21006955206394196D));
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.69563579559326172D), Telerik.Reporting.Drawing.Unit.Inch(0.17703646421432495D));
            this.textBox74.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox74.Style.Font.Bold = true;
            this.textBox74.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox74.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox74.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox74.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox74.Value = "EXTERIORES";
            // 
            // chkbotonesinteriores
            // 
            this.chkbotonesinteriores.FalseValue = "False";
            this.chkbotonesinteriores.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(1.7999123334884644D));
            this.chkbotonesinteriores.Name = "chkbotonesinteriores";
            this.chkbotonesinteriores.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.4236111640930176D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkbotonesinteriores.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkbotonesinteriores.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkbotonesinteriores.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkbotonesinteriores.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkbotonesinteriores.Text = "BOTONES DE INTERIORES";
            this.chkbotonesinteriores.Value = "False";
            // 
            // chkcinturones
            // 
            this.chkcinturones.FalseValue = "False";
            this.chkcinturones.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(1.6215269565582275D));
            this.chkcinturones.Name = "chkcinturones";
            this.chkcinturones.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0916666984558106D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcinturones.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcinturones.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcinturones.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkcinturones.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcinturones.Text = "CINTURONES";
            this.chkcinturones.Value = "False";
            // 
            // chkcenicero
            // 
            this.chkcenicero.FalseValue = "False";
            this.chkcenicero.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(1.4431414604187012D));
            this.chkcenicero.Name = "chkcenicero";
            this.chkcenicero.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.2609139680862427D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcenicero.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcenicero.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcenicero.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkcenicero.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcenicero.Text = "CENICEROS";
            this.chkcenicero.Value = "False";
            // 
            // chkespejoretrovisor
            // 
            this.chkespejoretrovisor.FalseValue = "False";
            this.chkespejoretrovisor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(1.2673609256744385D));
            this.chkespejoretrovisor.Name = "chkespejoretrovisor";
            this.chkespejoretrovisor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.2916669845581055D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkespejoretrovisor.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkespejoretrovisor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkespejoretrovisor.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkespejoretrovisor.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkespejoretrovisor.Text = "ESPEJO RETROVISOR";
            this.chkespejoretrovisor.Value = "False";
            // 
            // chkencendedor
            // 
            this.chkencendedor.FalseValue = "False";
            this.chkencendedor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(1.0889761447906494D));
            this.chkencendedor.Name = "chkencendedor";
            this.chkencendedor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.153969407081604D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkencendedor.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkencendedor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkencendedor.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkencendedor.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkencendedor.Text = "ENCENDEDOR";
            this.chkencendedor.Value = "False";
            // 
            // chkbocinas
            // 
            this.chkbocinas.FalseValue = "False";
            this.chkbocinas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(0.91059070825576782D));
            this.chkbocinas.Name = "chkbocinas";
            this.chkbocinas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.2916669845581055D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkbocinas.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkbocinas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkbocinas.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkbocinas.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkbocinas.Text = "BOCINAS";
            this.chkbocinas.Value = "False";
            // 
            // chkradio
            // 
            this.chkradio.FalseValue = "False";
            this.chkradio.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(0.73220527172088623D));
            this.chkradio.Name = "chkradio";
            this.chkradio.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.1914688348770142D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkradio.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkradio.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkradio.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkradio.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkradio.Text = "RADIO";
            this.chkradio.Value = "False";
            // 
            // chkcalefaccion
            // 
            this.chkcalefaccion.FalseValue = "False";
            this.chkcalefaccion.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(0.55381923913955688D));
            this.chkcalefaccion.Name = "chkcalefaccion";
            this.chkcalefaccion.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.85277760028839111D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcalefaccion.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcalefaccion.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcalefaccion.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkcalefaccion.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcalefaccion.Text = "CALEFACCI�N ";
            this.chkcalefaccion.Value = "False";
            // 
            // chkinstrumentostablero
            // 
            this.chkinstrumentostablero.FalseValue = "False";
            this.chkinstrumentostablero.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3923563957214355D), Telerik.Reporting.Drawing.Unit.Inch(0.37673589587211609D));
            this.chkinstrumentostablero.Name = "chkinstrumentostablero";
            this.chkinstrumentostablero.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.4379973411560059D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkinstrumentostablero.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkinstrumentostablero.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkinstrumentostablero.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.chkinstrumentostablero.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkinstrumentostablero.Text = "INSTRUMENTOS DE TABLERO";
            this.chkinstrumentostablero.Value = "False";
            // 
            // chkcarroseria
            // 
            this.chkcarroseria.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkcarroseria.FalseValue = "False";
            this.chkcarroseria.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.20451401174068451D), Telerik.Reporting.Drawing.Unit.Inch(1.9717873334884644D));
            this.chkcarroseria.Name = "chkcarroseria";
            this.chkcarroseria.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.310416579246521D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcarroseria.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcarroseria.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcarroseria.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkcarroseria.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkcarroseria.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcarroseria.Text = "CARROSER�A SIN GOLPES";
            this.chkcarroseria.Value = "False";
            // 
            // chktapongasolina
            // 
            this.chktapongasolina.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chktapongasolina.FalseValue = "False";
            this.chktapongasolina.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.39722201228141785D), Telerik.Reporting.Drawing.Unit.Inch(1.7934019565582275D));
            this.chktapongasolina.Name = "chktapongasolina";
            this.chktapongasolina.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.1197917461395264D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chktapongasolina.Style.Color = System.Drawing.Color.DarkBlue;
            this.chktapongasolina.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chktapongasolina.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chktapongasolina.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chktapongasolina.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chktapongasolina.Text = "TAP�N DE GASOLINA";
            this.chktapongasolina.Value = "False";
            // 
            // chkmoldaduras
            // 
            this.chkmoldaduras.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkmoldaduras.FalseValue = "False";
            this.chkmoldaduras.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.26093772053718567D), Telerik.Reporting.Drawing.Unit.Inch(1.6150164604187012D));
            this.chkmoldaduras.Name = "chkmoldaduras";
            this.chkmoldaduras.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.2555553913116455D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkmoldaduras.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkmoldaduras.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkmoldaduras.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkmoldaduras.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkmoldaduras.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkmoldaduras.Text = "MOLDURAS COMPLETAS";
            this.chkmoldaduras.Value = "False";
            // 
            // chktapas
            // 
            this.chktapas.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chktapas.FalseValue = "False";
            this.chktapas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.52482640743255615D), Telerik.Reporting.Drawing.Unit.Inch(1.4379332065582275D));
            this.chktapas.Name = "chktapas";
            this.chktapas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.99166649580001831D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chktapas.Style.Color = System.Drawing.Color.DarkBlue;
            this.chktapas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chktapas.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chktapas.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chktapas.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chktapas.Text = "TAPAS";
            this.chktapas.Value = "False";
            // 
            // chkemblema
            // 
            this.chkemblema.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkemblema.FalseValue = "False";
            this.chkemblema.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.519618034362793D), Telerik.Reporting.Drawing.Unit.Inch(1.2621526718139648D));
            this.chkemblema.Name = "chkemblema";
            this.chkemblema.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.99571478366851807D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkemblema.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkemblema.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkemblema.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkemblema.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkemblema.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkemblema.Text = "EMBLEMA";
            this.chkemblema.Value = "False";
            // 
            // chkcristales
            // 
            this.chkcristales.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkcristales.FalseValue = "False";
            this.chkcristales.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.81649422645568848D), Telerik.Reporting.Drawing.Unit.Inch(1.0837677717208862D));
            this.chkcristales.Name = "chkcristales";
            this.chkcristales.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.69999980926513672D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcristales.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcristales.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcristales.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkcristales.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkcristales.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcristales.Text = "CRISTALES";
            this.chkcristales.Value = "False";
            // 
            // chkespejolateral
            // 
            this.chkespejolateral.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkespejolateral.FalseValue = "False";
            this.chkespejolateral.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.46232596039772034D), Telerik.Reporting.Drawing.Unit.Inch(0.90798652172088623D));
            this.chkespejolateral.Name = "chkespejolateral";
            this.chkespejolateral.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0541664361953735D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkespejolateral.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkespejolateral.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkespejolateral.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkespejolateral.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkespejolateral.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkespejolateral.Text = "ESPEJO LATERAL";
            this.chkespejolateral.Value = "False";
            // 
            // chkantena
            // 
            this.chkantena.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkantena.FalseValue = "False";
            this.chkantena.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.32170107960700989D), Telerik.Reporting.Drawing.Unit.Inch(0.73220527172088623D));
            this.chkantena.Name = "chkantena";
            this.chkantena.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.1957147121429443D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkantena.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkantena.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkantena.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkantena.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkantena.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkantena.Text = "ANTENA";
            this.chkantena.Value = "False";
            // 
            // chkcuartoluces
            // 
            this.chkcuartoluces.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkcuartoluces.FalseValue = "False";
            this.chkcuartoluces.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.64201462268829346D), Telerik.Reporting.Drawing.Unit.Inch(0.55381923913955688D));
            this.chkcuartoluces.Name = "chkcuartoluces";
            this.chkcuartoluces.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.87708312273025513D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkcuartoluces.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkcuartoluces.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkcuartoluces.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkcuartoluces.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkcuartoluces.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkcuartoluces.Text = "1/4 DE LUCES";
            this.chkcuartoluces.Value = "False";
            // 
            // chkunidadluces
            // 
            this.chkunidadluces.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkunidadluces.FalseValue = "False";
            this.chkunidadluces.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.52482640743255615D), Telerik.Reporting.Drawing.Unit.Inch(0.37673589587211609D));
            this.chkunidadluces.Name = "chkunidadluces";
            this.chkunidadluces.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.99571478366851807D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.chkunidadluces.Style.Color = System.Drawing.Color.DarkBlue;
            this.chkunidadluces.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.chkunidadluces.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.chkunidadluces.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.chkunidadluces.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.chkunidadluces.Text = "UNIDAD DE LUCES";
            this.chkunidadluces.Value = "False";
            // 
            // textBox75
            // 
            this.textBox75.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.60069465637207D), Telerik.Reporting.Drawing.Unit.Inch(0.23090285062789917D));
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.59992080926895142D), Telerik.Reporting.Drawing.Unit.Inch(0.17703646421432495D));
            this.textBox75.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox75.Style.Font.Bold = true;
            this.textBox75.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox75.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox75.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox75.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox75.Value = "INTERIORES";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.2638885974884033D), Telerik.Reporting.Drawing.Unit.Inch(0.28298631310462952D));
            this.pictureBox1.MimeType = "image/png";
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(3.3658528327941895D), Telerik.Reporting.Drawing.Unit.Inch(2.0236108303070068D));
            this.pictureBox1.Value = ((object)(resources.GetObject("pictureBox1.Value")));
            // 
            // checkbocinaclaxon
            // 
            this.checkbocinaclaxon.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkbocinaclaxon.FalseValue = "False";
            this.checkbocinaclaxon.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.434721976518631D), Telerik.Reporting.Drawing.Unit.Inch(2.1499128341674805D));
            this.checkbocinaclaxon.Name = "checkbocinaclaxon";
            this.checkbocinaclaxon.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0812498331069946D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkbocinaclaxon.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkbocinaclaxon.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkbocinaclaxon.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.checkbocinaclaxon.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.checkbocinaclaxon.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkbocinaclaxon.Text = "BOCINA DE CLAX�N";
            this.checkbocinaclaxon.Value = "False";
            // 
            // checklimpiaparabrisas
            // 
            this.checklimpiaparabrisas.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checklimpiaparabrisas.FalseValue = "False";
            this.checklimpiaparabrisas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.39583301544189453D), Telerik.Reporting.Drawing.Unit.Inch(2.3332457542419434D));
            this.checklimpiaparabrisas.Name = "checklimpiaparabrisas";
            this.checklimpiaparabrisas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.1159720420837402D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checklimpiaparabrisas.Style.Color = System.Drawing.Color.DarkBlue;
            this.checklimpiaparabrisas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checklimpiaparabrisas.Style.LineColor = System.Drawing.Color.DarkBlue;
            this.checklimpiaparabrisas.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.checklimpiaparabrisas.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checklimpiaparabrisas.Text = "LIMPIA PARABRISAS";
            this.checklimpiaparabrisas.Value = "False";
            // 
            // checkmanijasinterior
            // 
            this.checkmanijasinterior.FalseValue = "False";
            this.checkmanijasinterior.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.395134449005127D), Telerik.Reporting.Drawing.Unit.Inch(1.9693566560745239D));
            this.checkmanijasinterior.Name = "checkmanijasinterior";
            this.checkmanijasinterior.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.4236111640930176D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkmanijasinterior.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkmanijasinterior.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkmanijasinterior.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkmanijasinterior.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkmanijasinterior.Text = "MANIJAS DE INTERIORES";
            this.checkmanijasinterior.Value = "False";
            // 
            // checktapetes
            // 
            this.checktapetes.FalseValue = "False";
            this.checktapetes.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.39307165145874D), Telerik.Reporting.Drawing.Unit.Inch(2.1445379257202148D));
            this.checktapetes.Name = "checktapetes";
            this.checktapetes.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.4236111640930176D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checktapetes.Style.Color = System.Drawing.Color.DarkBlue;
            this.checktapetes.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checktapetes.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checktapetes.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checktapetes.Text = "TAPETES";
            this.checktapetes.Value = "False";
            // 
            // checkvestiduras
            // 
            this.checkvestiduras.FalseValue = "False";
            this.checkvestiduras.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3930721282958984D), Telerik.Reporting.Drawing.Unit.Inch(2.3112046718597412D));
            this.checkvestiduras.Name = "checkvestiduras";
            this.checkvestiduras.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.4236111640930176D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkvestiduras.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkvestiduras.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkvestiduras.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkvestiduras.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkvestiduras.Text = "VESTIDURAS";
            this.checkvestiduras.Value = "False";
            // 
            // checkgato
            // 
            this.checkgato.FalseValue = "False";
            this.checkgato.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.36458349227905273D), Telerik.Reporting.Drawing.Unit.Inch(2.6238944530487061D));
            this.checkgato.Name = "checkgato";
            this.checkgato.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkgato.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkgato.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkgato.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkgato.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkgato.Text = "GATO";
            this.checkgato.TrueValue = "= True";
            this.checkgato.Value = "False";
            // 
            // checkestucheherramientas
            // 
            this.checkestucheherramientas.FalseValue = "False";
            this.checkestucheherramientas.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.36458349227905273D), Telerik.Reporting.Drawing.Unit.Inch(2.8009777069091797D));
            this.checkestucheherramientas.Name = "checkestucheherramientas";
            this.checkestucheherramientas.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.5781252384185791D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkestucheherramientas.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkestucheherramientas.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkestucheherramientas.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkestucheherramientas.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkestucheherramientas.Text = "ESTUCHE DE HERRAMIENTAS";
            this.checkestucheherramientas.TrueValue = "= True";
            this.checkestucheherramientas.Value = "False";
            // 
            // checkclaxon
            // 
            this.checkclaxon.FalseValue = "False";
            this.checkclaxon.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.36458349227905273D), Telerik.Reporting.Drawing.Unit.Inch(2.9780609607696533D));
            this.checkclaxon.Name = "checkclaxon";
            this.checkclaxon.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkclaxon.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkclaxon.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkclaxon.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkclaxon.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkclaxon.Text = "CLAX�N";
            this.checkclaxon.TrueValue = "= True";
            this.checkclaxon.Value = "False";
            // 
            // checkvarillaaceite
            // 
            this.checkvarillaaceite.FalseValue = "False";
            this.checkvarillaaceite.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(0.36458349227905273D), Telerik.Reporting.Drawing.Unit.Inch(3.1551444530487061D));
            this.checkvarillaaceite.Name = "checkvarillaaceite";
            this.checkvarillaaceite.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkvarillaaceite.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkvarillaaceite.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkvarillaaceite.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkvarillaaceite.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkvarillaaceite.Text = "VARILLA DE ACEITE";
            this.checkvarillaaceite.TrueValue = "= True";
            this.checkvarillaaceite.Value = "False";
            // 
            // checkmaneralgato
            // 
            this.checkmaneralgato.FalseValue = "False";
            this.checkmaneralgato.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.6312501430511475D), Telerik.Reporting.Drawing.Unit.Inch(2.6301441192626953D));
            this.checkmaneralgato.Name = "checkmaneralgato";
            this.checkmaneralgato.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkmaneralgato.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkmaneralgato.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkmaneralgato.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkmaneralgato.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkmaneralgato.Text = "MANERAL DE GATO";
            this.checkmaneralgato.TrueValue = "= True";
            this.checkmaneralgato.Value = "False";
            // 
            // checktrianguloseg
            // 
            this.checktrianguloseg.FalseValue = "False";
            this.checktrianguloseg.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.6312501430511475D), Telerik.Reporting.Drawing.Unit.Inch(2.8072273731231689D));
            this.checktrianguloseg.Name = "checktrianguloseg";
            this.checktrianguloseg.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.5781252384185791D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checktrianguloseg.Style.Color = System.Drawing.Color.DarkBlue;
            this.checktrianguloseg.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checktrianguloseg.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checktrianguloseg.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checktrianguloseg.Text = "TRI�NGULO DE SEGURIDAD";
            this.checktrianguloseg.TrueValue = "= True";
            this.checktrianguloseg.Value = "False";
            // 
            // checktaponaceite
            // 
            this.checktaponaceite.FalseValue = "False";
            this.checktaponaceite.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.6312501430511475D), Telerik.Reporting.Drawing.Unit.Inch(2.9843108654022217D));
            this.checktaponaceite.Name = "checktaponaceite";
            this.checktaponaceite.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checktaponaceite.Style.Color = System.Drawing.Color.DarkBlue;
            this.checktaponaceite.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checktaponaceite.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checktaponaceite.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checktaponaceite.Text = "TAP�N DE ACEITE";
            this.checktaponaceite.TrueValue = "= True";
            this.checktaponaceite.Value = "False";
            // 
            // checkfiltroaire
            // 
            this.checkfiltroaire.FalseValue = "False";
            this.checkfiltroaire.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.6312501430511475D), Telerik.Reporting.Drawing.Unit.Inch(3.1613941192626953D));
            this.checkfiltroaire.Name = "checkfiltroaire";
            this.checkfiltroaire.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkfiltroaire.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkfiltroaire.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkfiltroaire.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkfiltroaire.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkfiltroaire.Text = "FILTRO DE AIRE";
            this.checkfiltroaire.TrueValue = "= True";
            this.checkfiltroaire.Value = "False";
            // 
            // checkllaverueda
            // 
            this.checkllaverueda.FalseValue = "False";
            this.checkllaverueda.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3979167938232422D), Telerik.Reporting.Drawing.Unit.Inch(2.6155605316162109D));
            this.checkllaverueda.Name = "checkllaverueda";
            this.checkllaverueda.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkllaverueda.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkllaverueda.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkllaverueda.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkllaverueda.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkllaverueda.Text = "LLAVE DE RUEDA";
            this.checkllaverueda.TrueValue = "= True";
            this.checkllaverueda.Value = "False";
            // 
            // checkllantarefaccion
            // 
            this.checkllantarefaccion.FalseValue = "False";
            this.checkllantarefaccion.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3979167938232422D), Telerik.Reporting.Drawing.Unit.Inch(2.7926437854766846D));
            this.checkllantarefaccion.Name = "checkllantarefaccion";
            this.checkllantarefaccion.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.5781252384185791D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkllantarefaccion.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkllantarefaccion.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkllantarefaccion.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkllantarefaccion.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkllantarefaccion.Text = "LLANTA DE REFACCI�N";
            this.checkllantarefaccion.TrueValue = "= True";
            this.checkllantarefaccion.Value = "False";
            // 
            // checktaponradiador
            // 
            this.checktaponradiador.FalseValue = "False";
            this.checktaponradiador.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3979167938232422D), Telerik.Reporting.Drawing.Unit.Inch(2.9697272777557373D));
            this.checktaponradiador.Name = "checktaponradiador";
            this.checktaponradiador.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.3635416030883789D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checktaponradiador.Style.Color = System.Drawing.Color.DarkBlue;
            this.checktaponradiador.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checktaponradiador.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checktaponradiador.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checktaponradiador.Text = "TAP�N DE RADIADOR";
            this.checktaponradiador.TrueValue = "= True";
            this.checktaponradiador.Value = "False";
            // 
            // checkbateriamca
            // 
            this.checkbateriamca.FalseValue = "False";
            this.checkbateriamca.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(6.3979167938232422D), Telerik.Reporting.Drawing.Unit.Inch(3.1468105316162109D));
            this.checkbateriamca.Name = "checkbateriamca";
            this.checkbateriamca.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(1.0614582300186157D), Telerik.Reporting.Drawing.Unit.Inch(0.17703649401664734D));
            this.checkbateriamca.Style.Color = System.Drawing.Color.DarkBlue;
            this.checkbateriamca.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.checkbateriamca.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.checkbateriamca.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.checkbateriamca.Text = "BATER�A (MCA)";
            this.checkbateriamca.TrueValue = "= True";
            this.checkbateriamca.Value = "False";
            // 
            // textBox49
            // 
            this.textBox49.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.028332710266113D), Telerik.Reporting.Drawing.Unit.Cm(8.54194164276123D));
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0817710161209106D), Telerik.Reporting.Drawing.Unit.Cm(0.33541667461395264D));
            this.textBox49.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox49.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox49.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox49.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox49.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox49.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox49.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox49.Value = "1/4";
            // 
            // textBox50
            // 
            this.textBox50.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.11577033996582D), Telerik.Reporting.Drawing.Unit.Cm(8.544586181640625D));
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0817710161209106D), Telerik.Reporting.Drawing.Unit.Cm(0.33541667461395264D));
            this.textBox50.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox50.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox50.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox50.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox50.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox50.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox50.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox50.Value = "1/2";
            // 
            // textBox51
            // 
            this.textBox51.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.203207015991211D), Telerik.Reporting.Drawing.Unit.Cm(8.5340023040771484D));
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0817710161209106D), Telerik.Reporting.Drawing.Unit.Cm(0.33541667461395264D));
            this.textBox51.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox51.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox51.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox51.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox51.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox51.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox51.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox51.Value = "3/4";
            // 
            // textBox52
            // 
            this.textBox52.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.268383026123047D), Telerik.Reporting.Drawing.Unit.Cm(8.5381412506103516D));
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0817710161209106D), Telerik.Reporting.Drawing.Unit.Cm(0.33541667461395264D));
            this.textBox52.Style.BorderColor.Default = System.Drawing.Color.DarkBlue;
            this.textBox52.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox52.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox52.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox52.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox52.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox52.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox52.Value = "4/4";
            // 
            // Observaciones
            // 
            this.Observaciones.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.0583332777023315D), Telerik.Reporting.Drawing.Unit.Cm(9.2342681884765625D));
            this.Observaciones.Name = "Observaciones";
            this.Observaciones.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.239999771118164D), Telerik.Reporting.Drawing.Unit.Cm(1.1468055248260498D));
            this.Observaciones.Style.BorderColor.Default = System.Drawing.Color.Transparent;
            this.Observaciones.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.Observaciones.Style.Font.Strikeout = false;
            this.Observaciones.Value = "";
            // 
            // textBox53
            // 
            this.textBox53.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(2.5902764797210693D), Telerik.Reporting.Drawing.Unit.Inch(4.2326221466064453D));
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.36944419145584106D), Telerik.Reporting.Drawing.Unit.Inch(0.29992121458053589D));
            this.textBox53.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox53.Style.Font.Bold = false;
            this.textBox53.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox53.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox53.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox53.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox53.Value = "00.00";
            // 
            // textBox54
            // 
            this.textBox54.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.0791654586791992D), Telerik.Reporting.Drawing.Unit.Inch(4.2353997230529785D));
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.69583308696746826D), Telerik.Reporting.Drawing.Unit.Inch(0.29992121458053589D));
            this.textBox54.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox54.Style.Font.Bold = false;
            this.textBox54.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox54.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox54.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox54.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox54.Value = "VIGENCIA AL: ";
            // 
            // textBox55
            // 
            this.textBox55.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Inch(3.7972209453582764D), Telerik.Reporting.Drawing.Unit.Inch(4.2312335968017578D));
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Inch(0.69583308696746826D), Telerik.Reporting.Drawing.Unit.Inch(0.29992121458053589D));
            this.textBox55.Style.Color = System.Drawing.Color.DarkBlue;
            this.textBox55.Style.Font.Bold = false;
            this.textBox55.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox55.Style.LineColor = System.Drawing.Color.LightSeaGreen;
            this.textBox55.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox55.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox55.Value = "";
            // 
            // RptOrden
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1});
            this.Name = "RptOrden";
            this.PageNumberingStyle = Telerik.Reporting.PageNumberingStyle.Continue;
            this.PageSettings.ContinuousPaper = false;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Letter;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.UnitOfMeasure = Telerik.Reporting.Drawing.UnitType.Cm;
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(20.5D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

            }
		#endregion
		
		private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
		private Telerik.Reporting.DetailSection detail;
		private Telerik.Reporting.PageFooterSection pageFooterSection1;
        private Telerik.Reporting.PictureBox pbxLogo;
        private Telerik.Reporting.TextBox textBox101;
        private Telerik.Reporting.TextBox textBox68;
        private Telerik.Reporting.TextBox textBox71;
        private Telerik.Reporting.TextBox textBox72;
        private Telerik.Reporting.TextBox textBox73;
        private Telerik.Reporting.TextBox textBox70;
        private Telerik.Reporting.TextBox Caja;
        private Telerik.Reporting.TextBox textBox80;
        private Telerik.Reporting.TextBox textBox83;
        private Telerik.Reporting.TextBox textBox84;
        private Telerik.Reporting.TextBox textBox74;
        private Telerik.Reporting.CheckBox chkbotonesinteriores;
        private Telerik.Reporting.CheckBox chkcinturones;
        private Telerik.Reporting.CheckBox chkcenicero;
        private Telerik.Reporting.CheckBox chkespejoretrovisor;
        private Telerik.Reporting.CheckBox chkencendedor;
        private Telerik.Reporting.CheckBox chkbocinas;
        private Telerik.Reporting.CheckBox chkradio;
        private Telerik.Reporting.CheckBox chkcalefaccion;
        private Telerik.Reporting.CheckBox chkinstrumentostablero;
        private Telerik.Reporting.CheckBox chkcarroseria;
        private Telerik.Reporting.CheckBox chktapongasolina;
        private Telerik.Reporting.CheckBox chkmoldaduras;
        private Telerik.Reporting.CheckBox chktapas;
        private Telerik.Reporting.CheckBox chkemblema;
        private Telerik.Reporting.CheckBox chkcristales;
        private Telerik.Reporting.CheckBox chkespejolateral;
        private Telerik.Reporting.CheckBox chkantena;
        private Telerik.Reporting.CheckBox chkcuartoluces;
        private Telerik.Reporting.CheckBox chkunidadluces;
        private Telerik.Reporting.TextBox textBox75;
        private Telerik.Reporting.PictureBox pictureBox1;
        private Telerik.Reporting.Table table1;
        private Telerik.Reporting.TextBox textBox90;
        private Telerik.Reporting.TextBox textBox94;
        private Telerik.Reporting.TextBox textBox89;
        private Telerik.Reporting.TextBox textBox91;
        private Telerik.Reporting.TextBox textBox93;
        private Telerik.Reporting.ObjectDataSource objectDataSource1;
        private Telerik.Reporting.TextBox textBox69;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox8;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox14;
        private Telerik.Reporting.TextBox textBox15;
        private Telerik.Reporting.TextBox textBox16;
        private Telerik.Reporting.TextBox textBox17;
        private Telerik.Reporting.TextBox textBox13;
        private Telerik.Reporting.TextBox textBox18;
        private Telerik.Reporting.TextBox textBox19;
        private Telerik.Reporting.TextBox textBox20;
        private Telerik.Reporting.TextBox textBox21;
        private Telerik.Reporting.TextBox textBox22;
        private Telerik.Reporting.TextBox textBox23;
        private Telerik.Reporting.TextBox textBox24;
        private Telerik.Reporting.TextBox textBox25;
        private Telerik.Reporting.TextBox textBox26;
        private Telerik.Reporting.TextBox textBox27;
        private Telerik.Reporting.TextBox textBox28;
        private Telerik.Reporting.PictureBox pictureBox2;
        private Telerik.Reporting.TextBox textBox30;
        private Telerik.Reporting.TextBox textBox32;
        private Telerik.Reporting.TextBox textBox34;
        private Telerik.Reporting.TextBox textBox29;
        private Telerik.Reporting.TextBox textBox31;
        private Telerik.Reporting.TextBox textBox33;
        private Telerik.Reporting.TextBox textBox45;
        private Telerik.Reporting.TextBox textBox44;
        private Telerik.Reporting.TextBox textBox38;
        private Telerik.Reporting.TextBox textBox92;
        private Telerik.Reporting.PictureBox pictureBox3;
        private Telerik.Reporting.Table table2;
        private Telerik.Reporting.TextBox textBox47;
        private Telerik.Reporting.TextBox textBox48;
        private Telerik.Reporting.TextBox textBox1;
        private Telerik.Reporting.CheckBox checkbocinaclaxon;
        private Telerik.Reporting.CheckBox checklimpiaparabrisas;
        private Telerik.Reporting.TextBox textBox46;
        private Telerik.Reporting.TextBox textBox35;
        private Telerik.Reporting.CheckBox checkmanijasinterior;
        private Telerik.Reporting.CheckBox checktapetes;
        private Telerik.Reporting.CheckBox checkvestiduras;
        private Telerik.Reporting.CheckBox checkgato;
        private Telerik.Reporting.CheckBox checkestucheherramientas;
        private Telerik.Reporting.CheckBox checkclaxon;
        private Telerik.Reporting.CheckBox checkvarillaaceite;
        private Telerik.Reporting.CheckBox checkmaneralgato;
        private Telerik.Reporting.CheckBox checktrianguloseg;
        private Telerik.Reporting.CheckBox checktaponaceite;
        private Telerik.Reporting.CheckBox checkfiltroaire;
        private Telerik.Reporting.CheckBox checkllaverueda;
        private Telerik.Reporting.CheckBox checkllantarefaccion;
        private Telerik.Reporting.CheckBox checktaponradiador;
        private Telerik.Reporting.TextBox textBox49;
        private Telerik.Reporting.TextBox textBox50;
        private Telerik.Reporting.TextBox textBox51;
        private Telerik.Reporting.TextBox textBox52;
        private Telerik.Reporting.TextBox Observaciones;
        private Telerik.Reporting.TextBox textBox53;
        private Telerik.Reporting.TextBox textBox54;
        private Telerik.Reporting.TextBox textBox55;
        private Telerik.Reporting.CheckBox checkbateriamca;
        private Telerik.Reporting.CheckBox pllantas;
        private Telerik.Reporting.CheckBox palineacion;
        private Telerik.Reporting.CheckBox pbalanceo;
        private Telerik.Reporting.CheckBox pamorti;
        private Telerik.Reporting.CheckBox psuspen;
        private Telerik.Reporting.CheckBox pfrenos;
        private Telerik.Reporting.CheckBox pcambioaceite;
    }
}